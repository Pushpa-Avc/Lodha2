'use client';

// ─────────────────────────────────────────────────────────────────────────────
// HOME PAGE — Cinematic scroll experience orchestrator
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import dynamic from 'next/dynamic';
import { Navigation } from '@/components/layout/Navigation';
import { LoadingScreen } from '@/components/ui/LoadingScreen';
import { BookingModal } from '@/components/ui/BookingModal';
import { SECTION_CONFIGS } from '@/lib/animation/section-configs';
import { PreloaderManager } from '@/lib/animation/frame-preloader';
import type { LoadingState } from '@/types';

// ─── Dynamic imports (code split per section) ─────────────────────────────────

const ScrollSequence = dynamic(
  () =>
    import('@/components/canvas/ScrollSequence').then((m) => m.ScrollSequence),
  { ssr: false }
);

// ─── Preloader Manager Instance ───────────────────────────────────────────────

const preloaderManager = new PreloaderManager();

// ─── Component ───────────────────────────────────────────────────────────────

export default function HomePage() {
  // Loading state
  const [loadingState, setLoadingState] = useState<LoadingState>({
    phase: 'loading',
    progress: 0,
    message: 'Preparing your experience',
    sectionsLoaded: [false, false, false, false, false],
  });

  const [appReady, setAppReady] = useState(false);
  const [currentSection, setCurrentSection] = useState(1);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  // ─── Section Preloading Strategy ───────────────────────────────────────

  useEffect(() => {
    let cancelled = false;

    async function loadSection1() {
      // Phase 1: Load Section 1 first (critical path)
      try {
        await preloaderManager.preloadSection(SECTION_CONFIGS[0], {
          priorityFrames: 20, // Get first 20 frames ASAP
          onProgress: (state) => {
            if (cancelled) return;
            setLoadingState((prev) => ({
              ...prev,
              progress: state.progress * 0.4, // Section 1 = 40% of loading bar
            }));
          },
        });

        if (cancelled) return;

        setLoadingState((prev) => ({
          ...prev,
          progress: 0.5,
          sectionsLoaded: [true, false, false, false, false],
        }));

        // Phase 2: Load Section 2 (preload next)
        await preloaderManager.preloadSection(SECTION_CONFIGS[1], {
          priorityFrames: 15,
          onProgress: (state) => {
            if (cancelled) return;
            setLoadingState((prev) => ({
              ...prev,
              progress: 0.5 + state.progress * 0.3,
            }));
          },
        });

        if (cancelled) return;

        setLoadingState((prev) => ({
          ...prev,
          progress: 0.8,
          phase: 'ready',
          sectionsLoaded: [true, true, false, false, false],
        }));

        // Phase 3: Load remaining sections lazily in background
        Promise.all([
          preloaderManager.preloadSection(SECTION_CONFIGS[2]),
          preloaderManager.preloadSection(SECTION_CONFIGS[3]),
          preloaderManager.preloadSection(SECTION_CONFIGS[4]),
        ]).then(() => {
          if (!cancelled) {
            setLoadingState((prev) => ({
              ...prev,
              progress: 1,
              sectionsLoaded: [true, true, true, true, true],
            }));
          }
        });
      } catch (err) {
        console.error('[Home] Section loading failed:', err);
        if (!cancelled) {
          setLoadingState((prev) => ({
            ...prev,
            phase: 'error',
            message: 'Loading failed. Please refresh.',
          }));
        }
      }
    }

    loadSection1();
    return () => {
      cancelled = true;
    };
  }, []);

  // ─── Handle loading complete ────────────────────────────────────────────

  const handleLoadingDone = useCallback(() => {
    setAppReady(true);
  }, []);

  // ─── Section tracking ───────────────────────────────────────────────────

  const handleSectionActive = useCallback((section: number) => {
    setCurrentSection(section);

    // Lazy-load upcoming section when approaching it
    const nextSection = section + 1;
    if (
      nextSection <= 5 &&
      !preloaderManager.isSectionLoaded(`section-${nextSection}-*`)
    ) {
      preloaderManager.preloadSection(SECTION_CONFIGS[nextSection - 1]);
    }
  }, []);

  // ─── Render ─────────────────────────────────────────────────────────────

  const isLoaded = loadingState.phase === 'ready' || loadingState.progress >= 0.8;

  return (
    <>
      {/* Loading Screen */}
      <LoadingScreen
        progress={loadingState.progress}
        isComplete={isLoaded}
        onAnimationDone={handleLoadingDone}
      />

      {/* Navigation */}
      <AnimatePresence>
        {appReady && (
          <Navigation
            currentSection={currentSection}
            onBookingOpen={() => setIsBookingOpen(true)}
          />
        )}
      </AnimatePresence>

      {/* Main Experience */}
      <main className="relative bg-brand-black">
        {SECTION_CONFIGS.map((config, index) => (
          <ScrollSequence
            key={config.id}
            config={config}
            priority={index === 0} // Section 1 is critical
            onSectionActive={handleSectionActive}
          />
        ))}

        {/* Footer */}
        <footer className="relative py-24 px-8 md:px-20 border-t border-brand-ash/10">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-12">
            {/* Brand */}
            <div className="space-y-2">
              <p className="font-display text-2xl text-brand-cream tracking-widest">
                LODHA
              </p>
              <p className="text-2xs text-gold-true tracking-display uppercase">
                Private Collection
              </p>
              <p className="text-xs text-brand-mist mt-4 max-w-xs">
                Macrotech Developers Ltd. RERA registered.
                <br />
                Mumbai · London · Dubai
              </p>
            </div>

            {/* Links */}
            <div className="flex flex-col gap-3">
              {['Privacy Policy', 'Terms of Use', 'RERA Disclosure', 'Contact'].map(
                (link) => (
                  <button
                    key={link}
                    className="text-2xs tracking-wider text-brand-mist hover:text-gold-pale transition-colors duration-300 text-left"
                  >
                    {link}
                  </button>
                )
              )}
            </div>

            {/* CTA */}
            <div className="space-y-4">
              <p className="text-sm text-brand-silver">
                Ready to arrive above the ordinary?
              </p>
              <button
                onClick={() => setIsBookingOpen(true)}
                className="inline-flex items-center gap-4 group"
              >
                <span className="text-2xs tracking-display uppercase text-brand-cream">
                  Request Private Viewing
                </span>
                <div className="w-6 h-px bg-gold-true group-hover:w-12 transition-all duration-600 ease-luxury" />
              </button>
            </div>
          </div>

          <div className="mt-16 pt-8 border-t border-brand-ash/10 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-2xs text-brand-ash/50 tracking-wide">
              © {new Date().getFullYear()} Macrotech Developers Ltd. All rights reserved.
            </p>
            <p className="text-2xs text-brand-ash/30 tracking-wide">
              This is not a booking. Images are for representational purposes only.
            </p>
          </div>
        </footer>
      </main>

      {/* Booking Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
      />

      {/* Custom cursor */}
      <CustomCursor />
    </>
  );
}

// ─── Custom Cursor ────────────────────────────────────────────────────────────

function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);
  const posRef = useRef({ x: -100, y: -100 });
  const targetRef = useRef({ x: -100, y: -100 });
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    // Only on desktop
    if (window.matchMedia('(pointer: coarse)').matches) return;

    const handleMouseMove = (e: MouseEvent) => {
      targetRef.current = { x: e.clientX, y: e.clientY };
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    // Smooth cursor lerp
    function lerp(a: number, b: number, t: number) {
      return a + (b - a) * t;
    }

    function animate() {
      posRef.current.x = lerp(posRef.current.x, targetRef.current.x, 0.12);
      posRef.current.y = lerp(posRef.current.y, targetRef.current.y, 0.12);

      if (cursorRef.current) {
        cursorRef.current.style.transform = `translate(${posRef.current.x - 16}px, ${posRef.current.y - 16}px)`;
      }
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${targetRef.current.x - 2}px, ${targetRef.current.y - 2}px)`;
      }

      rafRef.current = requestAnimationFrame(animate);
    }

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <>
      {/* Outer ring */}
      <div
        ref={cursorRef}
        className="fixed top-0 left-0 w-8 h-8 border border-gold-true/30 rounded-full pointer-events-none z-[998] mix-blend-difference hidden md:block"
        aria-hidden="true"
        style={{ willChange: 'transform' }}
      />
      {/* Inner dot */}
      <div
        ref={dotRef}
        className="fixed top-0 left-0 w-1 h-1 bg-gold-true rounded-full pointer-events-none z-[998] hidden md:block"
        aria-hidden="true"
        style={{ willChange: 'transform' }}
      />
    </>
  );
}
