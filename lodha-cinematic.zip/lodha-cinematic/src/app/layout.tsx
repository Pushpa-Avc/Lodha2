import type { Metadata, Viewport } from 'next';
import { Cormorant_Garamond, Cormorant } from 'next/font/google';
import '@/styles/globals.css';
import { LenisProvider } from '@/lib/animation/lenis-provider';

// ─── Fonts ───────────────────────────────────────────────────────────────────

const cormorantGaramond = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-display',
  display: 'swap',
  preload: true,
});

const cormorant = Cormorant({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-serif',
  display: 'swap',
  preload: false,
});

// ─── Metadata ────────────────────────────────────────────────────────────────

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? 'https://lodha-cinematic.vercel.app'
  ),
  title: {
    default: 'Lodha Private Collection — Architecture Above the Ordinary',
    template: '%s | Lodha Private Collection',
  },
  description:
    'Experience Mumbai's most extraordinary addresses. A private collection of residences defined by precision, restraint, and global ambition.',
  keywords: [
    'Lodha',
    'luxury real estate Mumbai',
    'private residences',
    'World One',
    'Lodha Malabar',
    'luxury apartments Mumbai',
    'premium real estate',
  ],
  authors: [{ name: 'Lodha Group' }],
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
    },
  },
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: 'https://lodha-cinematic.vercel.app',
    siteName: 'Lodha Private Collection',
    title: 'Lodha Private Collection — Architecture Above the Ordinary',
    description:
      'Experience Mumbai's most extraordinary addresses. Residences defined by precision, restraint, and global ambition.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Lodha Private Collection',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Lodha Private Collection',
    description: 'Architecture Above the Ordinary.',
    images: ['/og-image.jpg'],
  },
};

export const viewport: Viewport = {
  themeColor: '#050505',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

// ─── Root Layout ─────────────────────────────────────────────────────────────

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${cormorantGaramond.variable} ${cormorant.variable}`}
      suppressHydrationWarning
    >
      <head>
        {/* DNS prefetch for performance */}
        <link rel="dns-prefetch" href="//fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.googleapis.com" crossOrigin="anonymous" />

        {/* Preload critical frame images */}
        <link
          rel="preload"
          as="image"
          href="/frames/section1/frame_0000.webp"
          type="image/webp"
        />
        <link
          rel="preload"
          as="image"
          href="/frames/section1/frame_0001.webp"
          type="image/webp"
        />
      </head>
      <body className="bg-brand-black text-brand-cream antialiased overflow-x-hidden">
        <LenisProvider lerp={0.07} duration={1.2}>
          {children}
        </LenisProvider>
      </body>
    </html>
  );
}
