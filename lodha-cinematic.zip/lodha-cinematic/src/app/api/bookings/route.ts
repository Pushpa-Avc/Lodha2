// ─────────────────────────────────────────────────────────────────────────────
// API ROUTE: POST /api/bookings
// Handles private viewing form submissions
// - Validates input with Zod
// - Stores to Supabase
// - Triggers Make.com webhook for email automation
// ─────────────────────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createServerClient } from '@/lib/supabase/client';
import type { BookingApiResponse } from '@/types';

// ─── Zod Schema ───────────────────────────────────────────────────────────────

const BookingSchema = z.object({
  full_name: z
    .string()
    .min(2, 'Name must be at least 2 characters')
    .max(100, 'Name too long')
    .trim(),

  email: z
    .string()
    .email('Please enter a valid email address')
    .toLowerCase()
    .trim(),

  phone: z
    .string()
    .regex(
      /^[+]?[\d\s\-()]{7,20}$/,
      'Please enter a valid phone number'
    )
    .trim(),

  property_interest: z
    .enum([
      'Lodha Malabar',
      'Lodha Altamount',
      'Lodha Trump Tower',
      'World One',
      'Lodha Seamont',
      'Other',
    ])
    .optional()
    .default('Other'),

  preferred_date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format')
    .optional(),

  preferred_time: z
    .enum([
      '10:00 AM',
      '11:00 AM',
      '12:00 PM',
      '2:00 PM',
      '3:00 PM',
      '4:00 PM',
      '5:00 PM',
    ])
    .optional(),

  message: z
    .string()
    .max(1000, 'Message too long')
    .trim()
    .optional(),

  source: z.string().default('website'),
  utm_source: z.string().optional(),
  utm_medium: z.string().optional(),
  utm_campaign: z.string().optional(),
});

// ─── Rate Limiter ─────────────────────────────────────────────────────────────

const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const RATE_LIMIT_MAX = 3; // Max 3 submissions per IP per minute
const ipSubmissions = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const record = ipSubmissions.get(ip);

  if (!record || now > record.resetAt) {
    ipSubmissions.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW });
    return true; // Allow
  }

  if (record.count >= RATE_LIMIT_MAX) {
    return false; // Block
  }

  record.count++;
  return true; // Allow
}

// ─── Make.com Webhook ─────────────────────────────────────────────────────────

async function triggerMakeWebhook(data: Record<string, unknown>): Promise<{
  success: boolean;
  response?: unknown;
  error?: string;
}> {
  const webhookUrl = process.env.MAKE_WEBHOOK_URL;

  if (!webhookUrl) {
    console.warn('[Webhook] MAKE_WEBHOOK_URL not configured. Skipping.');
    return { success: false, error: 'Webhook URL not configured' };
  }

  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Lodha-Token': process.env.WEBHOOK_SECRET ?? '',
      },
      body: JSON.stringify({
        event: 'private_viewing_request',
        timestamp: new Date().toISOString(),
        data,
      }),
      signal: AbortSignal.timeout(10000), // 10s timeout
    });

    if (!response.ok) {
      throw new Error(`Webhook returned ${response.status}`);
    }

    const responseData = await response.json().catch(() => ({}));
    return { success: true, response: responseData };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    console.error('[Webhook] Failed:', message);
    return { success: false, error: message };
  }
}

// ─── Route Handler ────────────────────────────────────────────────────────────

export async function POST(
  request: NextRequest
): Promise<NextResponse<BookingApiResponse>> {
  // Get IP for rate limiting
  const ip =
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ??
    request.headers.get('x-real-ip') ??
    'unknown';

  // Rate limit check
  if (!checkRateLimit(ip)) {
    return NextResponse.json(
      {
        success: false,
        error: 'Too many requests. Please try again in a moment.',
      },
      {
        status: 429,
        headers: {
          'Retry-After': '60',
        },
      }
    );
  }

  // Parse request body
  let rawBody: unknown;
  try {
    rawBody = await request.json();
  } catch {
    return NextResponse.json(
      { success: false, error: 'Invalid request body' },
      { status: 400 }
    );
  }

  // Validate with Zod
  const validation = BookingSchema.safeParse(rawBody);

  if (!validation.success) {
    const errors = validation.error.errors.map((e) => e.message).join(', ');
    return NextResponse.json(
      { success: false, error: errors },
      { status: 422 }
    );
  }

  const bookingData = validation.data;

  // Insert into Supabase
  const supabase = createServerClient();

  const { data: booking, error: dbError } = await supabase
    .from('bookings')
    .insert({
      full_name: bookingData.full_name,
      email: bookingData.email,
      phone: bookingData.phone,
      property_interest: bookingData.property_interest,
      preferred_date: bookingData.preferred_date,
      preferred_time: bookingData.preferred_time,
      message: bookingData.message,
      source: bookingData.source,
      utm_source: bookingData.utm_source,
      utm_medium: bookingData.utm_medium,
      utm_campaign: bookingData.utm_campaign,
      status: 'new',
    })
    .select()
    .single();

  if (dbError || !booking) {
    console.error('[Bookings API] Database error:', dbError);

    return NextResponse.json(
      {
        success: false,
        error:
          'We encountered an issue saving your request. Please try again or call us directly.',
      },
      { status: 500 }
    );
  }

  // Trigger Make.com webhook asynchronously
  const webhookResult = await triggerMakeWebhook({
    booking_id: booking.id,
    full_name: booking.full_name,
    email: booking.email,
    phone: booking.phone,
    property_interest: booking.property_interest,
    preferred_date: booking.preferred_date,
    preferred_time: booking.preferred_time,
    message: booking.message,
    source: booking.source,
    created_at: booking.created_at,
  });

  // Update webhook status in database
  if (webhookResult.success) {
    await supabase
      .from('bookings')
      .update({
        webhook_triggered: true,
        webhook_response: webhookResult.response as Record<string, unknown>,
      })
      .eq('id', booking.id);
  }

  return NextResponse.json(
    {
      success: true,
      bookingId: booking.id,
      webhookTriggered: webhookResult.success,
      message:
        'Your private viewing has been requested. Our team will reach out within 24 hours.',
    },
    { status: 201 }
  );
}

// ─── GET: Health check ────────────────────────────────────────────────────────

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    service: 'bookings',
    timestamp: new Date().toISOString(),
  });
}
