'use client';

// ─────────────────────────────────────────────────────────────────────────────
// NAVIGATION — Minimal luxury cinematic nav
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useMotionValueEvent, useScroll } from 'framer-motion';
import { useScrollTo } from '@/lib/animation/lenis-provider';

const NAV_SECTIONS = [
  { label: 'Arrival', index: 1 },
  { label: 'Skyline', index: 2 },
  { label: 'Tower', index: 3 },
  { label: 'Blueprint', index: 4 },
  { label: 'Global', index: 5 },
];

interface NavProps {
  currentSection?: number;
  onBookingOpen?: () => void;
}

export function Navigation({ currentSection = 1, onBookingOpen }: NavProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { scrollY } = useScroll();
  const scrollTo = useScrollTo();

  useMotionValueEvent(scrollY, 'change', (y) => {
    setIsScrolled(y > 80);
  });

  const handleSectionNav = (index: number) => {
    const el = document.querySelector(`[data-section="${index}"]`);
    if (el) scrollTo(el as HTMLElement, { duration: 2 });
    setIsMenuOpen(false);
  };

  return (
    <>
      {/* Top Navigation Bar */}
      <motion.nav
        className="fixed top-0 left-0 right-0 z-[100] flex items-center justify-between px-8 md:px-16 py-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
      >
        {/* Blur backdrop when scrolled */}
        <AnimatePresence>
          {isScrolled && (
            <motion.div
              className="absolute inset-0 bg-brand-black/60 backdrop-blur-md"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              aria-hidden="true"
            />
          )}
        </AnimatePresence>

        {/* Logo */}
        <motion.div className="relative z-10 cursor-pointer" onClick={() => scrollTo(0)}>
          <div className="flex flex-col">
            <span className="font-display text-lg text-brand-cream tracking-widest">
              LODHA
            </span>
            <span className="text-2xs text-gold-true tracking-display uppercase mt-0.5">
              Private Collection
            </span>
          </div>
        </motion.div>

        {/* Section dots — desktop */}
        <div className="relative z-10 hidden md:flex items-center gap-8">
          {NAV_SECTIONS.map((section) => (
            <button
              key={section.index}
              onClick={() => handleSectionNav(section.index)}
              className="group flex items-center gap-2 text-2xs tracking-display uppercase transition-colors duration-300"
              aria-label={`Navigate to ${section.label} section`}
            >
              <span
                className={`w-1 h-1 rounded-full transition-all duration-300 ${
                  currentSection === section.index
                    ? 'bg-gold-true scale-150'
                    : 'bg-brand-ash group-hover:bg-brand-pearl'
                }`}
              />
              <span
                className={`transition-colors duration-300 ${
                  currentSection === section.index
                    ? 'text-gold-pale'
                    : 'text-brand-mist group-hover:text-brand-pearl'
                }`}
              >
                {section.label}
              </span>
            </button>
          ))}
        </div>

        {/* CTA */}
        <div className="relative z-10 flex items-center gap-6">
          <motion.button
            onClick={onBookingOpen}
            className="hidden md:block text-2xs tracking-display uppercase text-brand-silver hover:text-gold-pale transition-colors duration-300 border-b border-transparent hover:border-gold-true/40 pb-0.5"
            whileHover={{ opacity: 0.85 }}
          >
            Private Viewing
          </motion.button>

          {/* Hamburger — mobile */}
          <button
            className="md:hidden relative w-6 h-4 flex flex-col justify-between"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
            aria-expanded={isMenuOpen}
          >
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="block h-px bg-brand-cream"
                animate={{
                  rotate: isMenuOpen && i === 0 ? 45 : isMenuOpen && i === 2 ? -45 : 0,
                  y: isMenuOpen && i === 0 ? 8 : isMenuOpen && i === 2 ? -8 : 0,
                  opacity: isMenuOpen && i === 1 ? 0 : 1,
                }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              />
            ))}
          </button>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            className="fixed inset-0 z-[99] bg-brand-black/95 backdrop-blur-xl flex flex-col items-center justify-center"
            initial={{ opacity: 0, clipPath: 'inset(0 0 100% 0)' }}
            animate={{ opacity: 1, clipPath: 'inset(0 0 0% 0)' }}
            exit={{ opacity: 0, clipPath: 'inset(0 0 100% 0)' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="flex flex-col items-center gap-8">
              {NAV_SECTIONS.map((section, i) => (
                <motion.button
                  key={section.index}
                  onClick={() => handleSectionNav(section.index)}
                  className="font-display text-4xl text-brand-cream hover:text-gold-pale transition-colors duration-300"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.5,
                    delay: i * 0.08,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  {section.label}
                </motion.button>
              ))}

              <motion.div
                className="mt-8 w-12 h-px bg-gold-true/30"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              />

              <motion.button
                onClick={() => {
                  setIsMenuOpen(false);
                  onBookingOpen?.();
                }}
                className="text-sm tracking-display uppercase text-gold-pale"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                Private Viewing
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Section Progress Bar */}
      <motion.div
        className="fixed bottom-0 left-0 right-0 z-[100] h-px bg-brand-ash/20"
        initial={{ opacity: 0 }}
        animate={{ opacity: isScrolled ? 1 : 0 }}
        transition={{ duration: 0.6 }}
        aria-hidden="true"
      >
        <motion.div
          className="h-full bg-gold-true/40"
          style={{
            width: `${(currentSection / 5) * 100}%`,
          }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        />
      </motion.div>
    </>
  );
}
