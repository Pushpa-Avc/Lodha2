'use client';

// ─────────────────────────────────────────────────────────────────────────────
// BOOKING FORM — Private Viewing Request
// Full form with react-hook-form, Zod validation, animated states
// ─────────────────────────────────────────────────────────────────────────────

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion, AnimatePresence } from 'framer-motion';
import type { BookingFormData, PropertyInterest, TimeSlot } from '@/types';

// ─── Validation Schema ───────────────────────────────────────────────────────

const schema = z.object({
  full_name: z.string().min(2, 'Please enter your name').max(100),
  email: z.string().email('Please enter a valid email'),
  phone: z
    .string()
    .regex(/^[+]?[\d\s\-()]{7,20}$/, 'Please enter a valid phone number'),
  property_interest: z
    .enum([
      'Lodha Malabar',
      'Lodha Altamount',
      'Lodha Trump Tower',
      'World One',
      'Lodha Seamont',
      'Other',
    ])
    .optional(),
  preferred_date: z.string().optional(),
  preferred_time: z
    .enum([
      '10:00 AM',
      '11:00 AM',
      '12:00 PM',
      '2:00 PM',
      '3:00 PM',
      '4:00 PM',
      '5:00 PM',
    ])
    .optional(),
  message: z.string().max(1000).optional(),
});

type FormValues = z.infer<typeof schema>;

// ─── Types ───────────────────────────────────────────────────────────────────

type FormState = 'idle' | 'submitting' | 'success' | 'error';

interface BookingFormProps {
  onSuccess?: () => void;
  defaultProperty?: PropertyInterest;
  className?: string;
}

// ─── Field Component ──────────────────────────────────────────────────────────

interface FieldProps {
  label: string;
  error?: string;
  children: React.ReactNode;
  required?: boolean;
}

function Field({ label, error, children, required }: FieldProps) {
  return (
    <div className="space-y-2">
      <label className="block text-2xs tracking-display uppercase text-brand-silver">
        {label}
        {required && (
          <span className="text-gold-true ml-1" aria-hidden="true">
            *
          </span>
        )}
      </label>
      {children}
      <AnimatePresence>
        {error && (
          <motion.p
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            className="text-2xs text-red-400/80"
            role="alert"
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Input Styles ─────────────────────────────────────────────────────────────

const inputClass = [
  'w-full bg-transparent border-b border-brand-ash/40',
  'py-3 px-0 text-sm text-brand-cream',
  'placeholder:text-brand-mist/50',
  'focus:outline-none focus:border-gold-true/60',
  'transition-colors duration-400',
  'font-sans tracking-wide',
].join(' ');

const selectClass = [
  inputClass,
  'appearance-none cursor-pointer',
  'bg-[url("data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2212%22 height=%228%22 viewBox=%220 0 12 8%22%3E%3Cpath d=%22M1 1l5 5 5-5%22 stroke=%22%239A9A9A%22 fill=%22none%22 stroke-width=%221.5%22/%3E%3C/svg%3E")]',
  'bg-no-repeat bg-[right_0.5rem_center]',
].join(' ');

// ─── Main Component ───────────────────────────────────────────────────────────

export function BookingForm({
  onSuccess,
  defaultProperty,
  className,
}: BookingFormProps) {
  const [formState, setFormState] = useState<FormState>('idle');
  const [serverError, setServerError] = useState<string>('');

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      property_interest: defaultProperty,
    },
  });

  const onSubmit = async (data: FormValues) => {
    setFormState('submitting');
    setServerError('');

    // Collect UTM params from URL
    const params = new URLSearchParams(window.location.search);
    const payload: BookingFormData = {
      ...data,
      source: 'website',
      utm_source: params.get('utm_source') ?? undefined,
      utm_medium: params.get('utm_medium') ?? undefined,
      utm_campaign: params.get('utm_campaign') ?? undefined,
    };

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error ?? 'Submission failed');
      }

      setFormState('success');
      reset();
      setTimeout(() => {
        onSuccess?.();
      }, 3000);
    } catch (err) {
      setFormState('error');
      setServerError(
        err instanceof Error
          ? err.message
          : 'An unexpected error occurred. Please try again.'
      );
    }
  };

  // ─── Success State ─────────────────────────────────────────────────────

  if (formState === 'success') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex flex-col items-center text-center space-y-6 py-16 ${className ?? ''}`}
      >
        {/* Gold check mark */}
        <div className="w-16 h-16 rounded-full border border-gold-true/30 flex items-center justify-center">
          <motion.svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            className="text-gold-true"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}
          >
            <path d="M5 13l4 4L19 7" />
          </motion.svg>
        </div>

        <div className="space-y-3">
          <h3 className="font-display text-2xl text-brand-cream">
            Your request has been received.
          </h3>
          <p className="text-sm text-brand-silver max-w-xs leading-relaxed">
            Our Private Client team will reach out within 24 hours to confirm
            your appointment.
          </p>
        </div>

        <div className="w-8 h-px bg-gold-true/30" />

        <p className="text-2xs text-brand-mist tracking-display uppercase">
          Lodha Private
        </p>
      </motion.div>
    );
  }

  // ─── Form State ────────────────────────────────────────────────────────

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className={`space-y-8 ${className ?? ''}`}
      noValidate
    >
      {/* Header */}
      <div className="space-y-2 mb-10">
        <p className="text-2xs tracking-display uppercase text-gold-true">
          Private Viewing
        </p>
        <h3 className="font-display text-3xl text-brand-cream">
          Request an Appointment
        </h3>
        <p className="text-sm text-brand-silver">
          A member of our Private Client team will confirm within 24 hours.
        </p>
      </div>

      {/* Personal Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Field label="Full Name" error={errors.full_name?.message} required>
          <input
            type="text"
            className={inputClass}
            placeholder="Rahul Mehta"
            autoComplete="name"
            {...register('full_name')}
          />
        </Field>

        <Field label="Email Address" error={errors.email?.message} required>
          <input
            type="email"
            className={inputClass}
            placeholder="rahul@example.com"
            autoComplete="email"
            {...register('email')}
          />
        </Field>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Field label="Mobile Number" error={errors.phone?.message} required>
          <input
            type="tel"
            className={inputClass}
            placeholder="+91 98765 43210"
            autoComplete="tel"
            {...register('phone')}
          />
        </Field>

        <Field
          label="Property Interest"
          error={errors.property_interest?.message}
        >
          <select className={selectClass} {...register('property_interest')}>
            <option value="" className="bg-brand-graphite">
              Select property
            </option>
            <option value="Lodha Malabar" className="bg-brand-graphite">
              Lodha Malabar
            </option>
            <option value="Lodha Altamount" className="bg-brand-graphite">
              Lodha Altamount
            </option>
            <option value="Lodha Trump Tower" className="bg-brand-graphite">
              Lodha Trump Tower
            </option>
            <option value="World One" className="bg-brand-graphite">
              World One
            </option>
            <option value="Lodha Seamont" className="bg-brand-graphite">
              Lodha Seamont
            </option>
            <option value="Other" className="bg-brand-graphite">
              Other / Not decided
            </option>
          </select>
        </Field>
      </div>

      {/* Scheduling */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Field label="Preferred Date" error={errors.preferred_date?.message}>
          <input
            type="date"
            className={inputClass}
            min={new Date().toISOString().split('T')[0]}
            {...register('preferred_date')}
            style={{ colorScheme: 'dark' }}
          />
        </Field>

        <Field
          label="Preferred Time"
          error={errors.preferred_time?.message}
        >
          <select className={selectClass} {...register('preferred_time')}>
            <option value="" className="bg-brand-graphite">
              Select time
            </option>
            {(
              [
                '10:00 AM',
                '11:00 AM',
                '12:00 PM',
                '2:00 PM',
                '3:00 PM',
                '4:00 PM',
                '5:00 PM',
              ] as TimeSlot[]
            ).map((time) => (
              <option key={time} value={time} className="bg-brand-graphite">
                {time}
              </option>
            ))}
          </select>
        </Field>
      </div>

      {/* Message */}
      <Field label="Message" error={errors.message?.message}>
        <textarea
          className={`${inputClass} resize-none h-24`}
          placeholder="Any specific requirements or questions..."
          {...register('message')}
        />
      </Field>

      {/* Server Error */}
      <AnimatePresence>
        {serverError && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 border border-red-500/20 bg-red-500/5 rounded"
            role="alert"
          >
            <p className="text-sm text-red-400">{serverError}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Submit */}
      <div className="pt-4">
        <motion.button
          type="submit"
          disabled={formState === 'submitting'}
          className={[
            'w-full py-4 px-8 text-sm tracking-display uppercase',
            'border border-gold-true/40 text-brand-cream',
            'hover:bg-gold-true/10 hover:border-gold-true/80',
            'transition-all duration-600',
            'disabled:opacity-40 disabled:cursor-not-allowed',
            'relative overflow-hidden group',
          ].join(' ')}
          whileHover={{ scale: 1.005 }}
          whileTap={{ scale: 0.998 }}
        >
          {/* Shimmer effect */}
          <span
            className="absolute inset-0 bg-gradient-to-r from-transparent via-gold-true/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1200 pointer-events-none"
            aria-hidden="true"
          />

          <span className="relative">
            {formState === 'submitting' ? (
              <span className="flex items-center justify-center gap-3">
                <span className="w-4 h-px bg-current animate-breath" />
                Processing
                <span className="w-4 h-px bg-current animate-breath" />
              </span>
            ) : (
              'Request Private Viewing'
            )}
          </span>
        </motion.button>

        <p className="mt-4 text-2xs text-brand-mist text-center tracking-wide">
          By submitting, you agree to be contacted by our Private Client team.
          <br />
          Your information is handled with the utmost discretion.
        </p>
      </div>
    </form>
  );
}
