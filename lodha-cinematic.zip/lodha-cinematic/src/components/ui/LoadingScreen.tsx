'use client';

// ─────────────────────────────────────────────────────────────────────────────
// LOADING SCREEN — Cinematic entry experience
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface LoadingScreenProps {
  progress: number; // 0–1
  isComplete: boolean;
  onAnimationDone?: () => void;
}

export function LoadingScreen({
  progress,
  isComplete,
  onAnimationDone,
}: LoadingScreenProps) {
  const [isExiting, setIsExiting] = useState(false);
  const [showContent, setShowContent] = useState(false);

  // Animate content in after a beat
  useEffect(() => {
    const t = setTimeout(() => setShowContent(true), 400);
    return () => clearTimeout(t);
  }, []);

  // Trigger exit when fully loaded
  useEffect(() => {
    if (isComplete) {
      const t = setTimeout(() => {
        setIsExiting(true);
        setTimeout(() => onAnimationDone?.(), 1200);
      }, 600);
      return () => clearTimeout(t);
    }
  }, [isComplete, onAnimationDone]);

  const percentage = Math.round(progress * 100);

  return (
    <AnimatePresence>
      {!isExiting && (
        <motion.div
          className="fixed inset-0 z-[999] bg-brand-black flex flex-col items-center justify-center"
          exit={{
            clipPath: 'inset(0 0 100% 0)',
            transition: { duration: 1.0, ease: [0.77, 0, 0.175, 1] },
          }}
          aria-label="Loading experience"
          role="progressbar"
          aria-valuenow={percentage}
          aria-valuemin={0}
          aria-valuemax={100}
        >
          {/* Background noise texture */}
          <div
            className="absolute inset-0 opacity-[0.03] pointer-events-none"
            style={{
              backgroundImage:
                "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
              backgroundSize: '200px 200px',
            }}
            aria-hidden="true"
          />

          <AnimatePresence>
            {showContent && (
              <motion.div
                className="flex flex-col items-center gap-12"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
              >
                {/* Logo mark */}
                <motion.div
                  className="flex flex-col items-center gap-1"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 1.2,
                    ease: [0.16, 1, 0.3, 1],
                    delay: 0.1,
                  }}
                >
                  {/* Decorative mark */}
                  <div className="w-px h-12 bg-gradient-to-b from-transparent via-gold-true to-transparent mb-6" />

                  <span className="font-display text-4xl md:text-5xl text-brand-cream tracking-widest">
                    LODHA
                  </span>
                  <span className="text-2xs text-gold-true tracking-display uppercase mt-2">
                    Private Collection
                  </span>
                </motion.div>

                {/* Progress bar */}
                <motion.div
                  className="w-48 flex flex-col items-center gap-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  {/* Track */}
                  <div className="relative w-full h-px bg-brand-ash/30 overflow-hidden">
                    <motion.div
                      className="absolute inset-y-0 left-0 bg-gold-true"
                      style={{ width: `${percentage}%` }}
                      transition={{ duration: 0.3, ease: 'linear' }}
                    />
                  </div>

                  {/* Percentage */}
                  <span className="text-2xs text-brand-mist tracking-display tabular-nums">
                    {percentage.toString().padStart(3, '0')}
                  </span>
                </motion.div>

                {/* Tagline */}
                <motion.p
                  className="text-2xs text-brand-ash/60 tracking-display uppercase"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 }}
                >
                  Preparing your experience
                </motion.p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
