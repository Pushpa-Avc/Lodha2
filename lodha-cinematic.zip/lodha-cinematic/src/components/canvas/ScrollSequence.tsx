'use client';

// ─────────────────────────────────────────────────────────────────────────────
// SCROLL SEQUENCE COMPONENT
// The core cinematic scroll-driven animation component.
// Renders a sticky canvas that maps scroll progress → frame index
// ─────────────────────────────────────────────────────────────────────────────

import React, {
  useRef,
  useEffect,
  useState,
  useCallback,
  useMemo,
} from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'framer-motion';
import type {
  FrameSequenceConfig,
  ScrollSequenceState,
  SectionContent,
} from '@/types';
import {
  scrollProgressToFrame,
  getTextOpacity,
  easeInOutSine,
  clamp,
} from '@/lib/animation/scroll-to-frame';
import { useFramePreloader } from '@/lib/animation/frame-preloader';

// ─── Props ───────────────────────────────────────────────────────────────────

interface ScrollSequenceProps {
  config: FrameSequenceConfig;
  className?: string;
  priority?: boolean;
  onProgress?: (progress: number) => void;
  onSectionActive?: (section: number) => void;
}

// ─── Section Copy Data ───────────────────────────────────────────────────────

const SECTION_CONTENT: Record<number, SectionContent> = {
  1: {
    headline: 'Arrive Above the Ordinary.',
    subheadline: 'Mumbai's finest address begins here.',
    body: 'From the moment you enter, the city falls silent beneath you.',
    revealAt: 0.1,
    hideAt: 0.85,
    align: 'left',
    position: 'bottom',
  },
  2: {
    headline: 'Where Mumbai\nMeets the Sky.',
    subheadline: 'A horizon that redefines expectation.',
    body: 'Every sunset is different. Every view, entirely yours.',
    revealAt: 0.1,
    hideAt: 0.85,
    align: 'center',
    position: 'center',
  },
  3: {
    headline: 'Architecture\nas a Statement.',
    subheadline: 'Standing singular on the city's crown.',
    body: 'Forty years of precision. One building that defines a skyline.',
    revealAt: 0.15,
    hideAt: 0.8,
    align: 'right',
    position: 'center',
  },
  4: {
    headline: 'Precision\nin Every Line.',
    subheadline: 'Engineered with intention. Designed without compromise.',
    body: 'Behind every curve, a decision. Behind every decision, mastery.',
    revealAt: 0.1,
    hideAt: 0.85,
    align: 'left',
    position: 'bottom',
  },
  5: {
    headline: 'Built for a\nGlobal Standard.',
    subheadline: 'From Mumbai to the world.',
    body: 'Lodha. Redefining what a home means for those who inhabit the extraordinary.',
    revealAt: 0.1,
    hideAt: 0.9,
    align: 'center',
    position: 'center',
    cta: {
      label: 'Schedule a Private Viewing',
      action: 'modal',
      variant: 'primary',
    },
  },
};

// ─── Component ───────────────────────────────────────────────────────────────

export const ScrollSequence = React.memo(function ScrollSequence({
  config,
  className,
  priority = false,
  onProgress,
  onSectionActive,
}: ScrollSequenceProps) {
  // Refs
  const containerRef = useRef<HTMLDivElement>(null);
  const stickyRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);
  const lastFrameRef = useRef<number>(-1);
  const animFrameRef = useRef<number>(0);

  // State
  const [sequenceState, setSequenceState] = useState<ScrollSequenceState>({
    currentFrame: 0,
    scrollProgress: 0,
    isPlaying: false,
    isLoaded: false,
    loadProgress: 0,
  });

  // Preload frames
  const preloaderState = useFramePreloader(config);

  // Framer Motion scroll tracking
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end'],
  });

  // ─── Canvas Rendering ───────────────────────────────────────────────────

  const renderFrame = useCallback(
    (frameIndex: number, frames: HTMLImageElement[]) => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const ctx = canvas.getContext('2d', { alpha: false });
      if (!ctx) return;

      const frame = frames[frameIndex];
      if (!frame || !frame.complete || frame.naturalWidth === 0) return;

      // Fit frame to canvas using "cover" strategy
      const canvasAspect = canvas.width / canvas.height;
      const frameAspect = frame.naturalWidth / frame.naturalHeight;

      let sx = 0, sy = 0, sw = frame.naturalWidth, sh = frame.naturalHeight;

      if (frameAspect > canvasAspect) {
        // Frame is wider — crop horizontally
        sw = frame.naturalHeight * canvasAspect;
        sx = (frame.naturalWidth - sw) / 2;
      } else {
        // Frame is taller — crop vertically
        sh = frame.naturalWidth / canvasAspect;
        sy = (frame.naturalHeight - sh) / 2;
      }

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';

      // Clear with brand black to prevent ghosting
      ctx.fillStyle = '#050505';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw frame
      ctx.drawImage(frame, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
    },
    []
  );

  // ─── Resize Handler ─────────────────────────────────────────────────────

  const handleResize = useCallback(() => {
    const canvas = canvasRef.current;
    const sticky = stickyRef.current;
    if (!canvas || !sticky) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2); // Cap at 2x for performance
    const rect = sticky.getBoundingClientRect();

    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;

    const ctx = canvas.getContext('2d', { alpha: false });
    if (ctx) ctx.scale(dpr, dpr);

    // Re-render current frame after resize
    if (preloaderState.frames.length > 0) {
      renderFrame(sequenceState.currentFrame, preloaderState.frames);
    }
  }, [preloaderState.frames, sequenceState.currentFrame, renderFrame]);

  // ─── Scroll Progress Handler ─────────────────────────────────────────────

  useEffect(() => {
    const unsubscribe = scrollYProgress.on('change', (progress) => {
      if (!preloaderState.isComplete) return;

      const frameIndex = scrollProgressToFrame({
        scrollProgress: progress,
        totalFrames: config.totalFrames,
        ease: easeInOutSine,
        snap: true,
      });

      // Only update if frame changed
      if (frameIndex !== lastFrameRef.current) {
        lastFrameRef.current = frameIndex;

        // Cancel pending RAF
        if (rafRef.current !== null) {
          cancelAnimationFrame(rafRef.current);
        }

        // Schedule render
        rafRef.current = requestAnimationFrame(() => {
          renderFrame(frameIndex, preloaderState.frames);
          setSequenceState((prev) => ({
            ...prev,
            currentFrame: frameIndex,
            scrollProgress: progress,
          }));
          onProgress?.(progress);

          // Detect section transitions
          if (progress > 0.1 && progress < 0.9) {
            onSectionActive?.(config.section);
          }
        });
      }
    });

    return () => {
      unsubscribe();
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, [
    scrollYProgress,
    config.totalFrames,
    config.section,
    preloaderState.isComplete,
    preloaderState.frames,
    renderFrame,
    onProgress,
    onSectionActive,
  ]);

  // ─── Initial Render on Load ──────────────────────────────────────────────

  useEffect(() => {
    if (preloaderState.isComplete && preloaderState.frames.length > 0) {
      handleResize();
      renderFrame(0, preloaderState.frames);
      setSequenceState((prev) => ({
        ...prev,
        isLoaded: true,
        loadProgress: 1,
      }));
    } else if (preloaderState.progress > 0) {
      setSequenceState((prev) => ({
        ...prev,
        loadProgress: preloaderState.progress,
      }));
    }
  }, [
    preloaderState.isComplete,
    preloaderState.progress,
    preloaderState.frames,
    renderFrame,
    handleResize,
  ]);

  // ─── Setup & Cleanup ─────────────────────────────────────────────────────

  useEffect(() => {
    handleResize();

    const observer = new ResizeObserver(handleResize);
    if (stickyRef.current) observer.observe(stickyRef.current);

    return () => {
      observer.disconnect();
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, [handleResize]);

  // ─── Computed Values ─────────────────────────────────────────────────────

  const content = useMemo(
    () => SECTION_CONTENT[config.section],
    [config.section]
  );

  const textOpacity = useTransform(
    scrollYProgress,
    [
      content?.revealAt ?? 0.1,
      Math.min((content?.revealAt ?? 0.1) + 0.15, 0.4),
      content?.hideAt ?? 0.85,
      Math.min((content?.hideAt ?? 0.85) + 0.1, 1),
    ],
    [0, 1, 1, 0]
  );

  const textY = useTransform(scrollYProgress, [0, 0.3], [30, 0]);

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <section
      ref={containerRef}
      data-section={config.section}
      className={`relative ${className ?? ''}`}
      style={{ height: `${config.scrollHeight}vh` }}
      aria-label={`Section ${config.section}: ${content?.headline}`}
    >
      {/* Loading Indicator */}
      {!sequenceState.isLoaded && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-brand-black pointer-events-none">
          <div className="flex flex-col items-center gap-6">
            <div className="relative w-16 h-px bg-brand-ash overflow-hidden">
              <motion.div
                className="absolute inset-y-0 left-0 bg-gold-true"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: sequenceState.loadProgress }}
                style={{ transformOrigin: 'left' }}
                transition={{ duration: 0.3 }}
              />
            </div>
            <span className="text-brand-silver text-2xs tracking-display uppercase">
              {Math.round(sequenceState.loadProgress * 100)}
            </span>
          </div>
        </div>
      )}

      {/* Sticky Frame Canvas */}
      <div
        ref={stickyRef}
        className="sticky top-0 w-full h-screen overflow-hidden"
      >
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
          aria-hidden="true"
        />

        {/* Cinematic Vignette */}
        <div
          className="absolute inset-0 pointer-events-none z-10"
          style={{
            background:
              'radial-gradient(ellipse at center, transparent 40%, rgba(5,5,5,0.6) 100%)',
          }}
          aria-hidden="true"
        />

        {/* Gradient Overlay — bottom fade */}
        <div
          className="absolute bottom-0 left-0 right-0 h-48 pointer-events-none z-10"
          style={{
            background:
              'linear-gradient(to top, rgba(5,5,5,0.8) 0%, transparent 100%)',
          }}
          aria-hidden="true"
        />

        {/* Section Content Overlay */}
        {content && (
          <motion.div
            className={`absolute inset-0 z-20 flex ${
              content.position === 'top'
                ? 'items-start'
                : content.position === 'bottom'
                ? 'items-end'
                : 'items-center'
            } ${
              content.align === 'left'
                ? 'justify-start'
                : content.align === 'right'
                ? 'justify-end'
                : 'justify-center'
            } p-12 md:p-20 xl:p-28 pointer-events-none`}
            style={{ opacity: textOpacity, y: textY }}
          >
            <div
              className={`max-w-2xl space-y-4 ${
                content.align === 'center' ? 'text-center mx-auto' : ''
              }`}
            >
              {/* Section number */}
              <div className="flex items-center gap-4 mb-6">
                <span
                  className="text-gold-true text-2xs tracking-display uppercase"
                  aria-hidden="true"
                >
                  {String(config.section).padStart(2, '0')}
                </span>
                <div className="w-12 h-px bg-gold-true/40" aria-hidden="true" />
              </div>

              {/* Main Headline */}
              <h2 className="font-display text-5xl md:text-6xl xl:text-7xl text-brand-cream leading-[0.95] tracking-snug whitespace-pre-line">
                {content.headline}
              </h2>

              {/* Subheadline */}
              {content.subheadline && (
                <p className="font-accent text-xl md:text-2xl text-gold-pale/80 mt-4 italic">
                  {content.subheadline}
                </p>
              )}

              {/* Body */}
              {content.body && (
                <p className="font-sans text-sm text-brand-silver tracking-wide leading-relaxed mt-6 max-w-sm">
                  {content.body}
                </p>
              )}

              {/* CTA */}
              {content.cta && (
                <motion.button
                  className="pointer-events-auto mt-8 inline-flex items-center gap-4 group"
                  whileHover={{ opacity: 0.8 }}
                  transition={{ duration: 0.3 }}
                  aria-label={content.cta.label}
                >
                  <span className="text-brand-cream text-sm tracking-wider uppercase">
                    {content.cta.label}
                  </span>
                  <div className="w-8 h-px bg-gold-true group-hover:w-16 transition-all duration-600 ease-luxury" />
                </motion.button>
              )}
            </div>
          </motion.div>
        )}

        {/* Scroll Progress Indicator */}
        <div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 pointer-events-none"
          aria-hidden="true"
        >
          <div className="w-px h-12 bg-brand-ash/40 overflow-hidden">
            <motion.div
              className="w-full bg-gold-true"
              style={{
                height: useTransform(
                  scrollYProgress,
                  [0, 1],
                  ['0%', '100%']
                ),
              }}
            />
          </div>
        </div>
      </div>
    </section>
  );
});

export default ScrollSequence;
