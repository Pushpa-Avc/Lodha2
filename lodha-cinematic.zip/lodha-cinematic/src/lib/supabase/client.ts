// ─────────────────────────────────────────────────────────────────────────────
// SUPABASE CLIENT
// Type-safe Supabase client with server/client variants
// ─────────────────────────────────────────────────────────────────────────────

import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types';

// ─── Environment Validation ───────────────────────────────────────────────────

function getSupabaseUrl(): string {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!url) {
    throw new Error(
      '[Supabase] NEXT_PUBLIC_SUPABASE_URL is not defined. ' +
      'Check your .env.local file.'
    );
  }
  return url;
}

function getSupabaseAnonKey(): string {
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!key) {
    throw new Error(
      '[Supabase] NEXT_PUBLIC_SUPABASE_ANON_KEY is not defined. ' +
      'Check your .env.local file.'
    );
  }
  return key;
}

function getSupabaseServiceKey(): string {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) {
    throw new Error(
      '[Supabase] SUPABASE_SERVICE_ROLE_KEY is not defined. ' +
      'This is required for server-side operations. Check your .env.local file.'
    );
  }
  return key;
}

// ─── Browser Client (Public/Anon) ─────────────────────────────────────────────

let browserClient: ReturnType<typeof createClient<Database>> | null = null;

/**
 * Get or create a browser-safe Supabase client
 * Uses anon key — subject to Row Level Security policies
 */
export function createBrowserClient() {
  if (browserClient) return browserClient;

  browserClient = createClient<Database>(
    getSupabaseUrl(),
    getSupabaseAnonKey(),
    {
      auth: {
        persistSession: false, // Stateless for this application
      },
      global: {
        headers: {
          'x-application-name': 'lodha-cinematic',
        },
      },
    }
  );

  return browserClient;
}

// ─── Server Client (Service Role) ─────────────────────────────────────────────

/**
 * Create a server-side Supabase client with service role
 * NEVER expose this to the browser — use only in API routes & Server Components
 */
export function createServerClient() {
  return createClient<Database>(
    getSupabaseUrl(),
    getSupabaseServiceKey(),
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
      global: {
        headers: {
          'x-application-name': 'lodha-cinematic-server',
        },
      },
    }
  );
}

// ─── Convenience Export ───────────────────────────────────────────────────────

export const supabase = createBrowserClient;
