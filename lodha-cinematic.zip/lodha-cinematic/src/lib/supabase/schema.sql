-- ─────────────────────────────────────────────────────────────────────────────
-- LODHA CINEMATIC — SUPABASE SCHEMA
-- Run this in your Supabase SQL Editor to set up the database
-- ─────────────────────────────────────────────────────────────────────────────

-- ─── Enable Extensions ───────────────────────────────────────────────────────

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── Enums ───────────────────────────────────────────────────────────────────

CREATE TYPE booking_status AS ENUM (
  'new',
  'contacted',
  'scheduled',
  'visited',
  'converted',
  'lost'
);

CREATE TYPE property_interest AS ENUM (
  'Lodha Malabar',
  'Lodha Altamount',
  'Lodha Trump Tower',
  'World One',
  'Lodha Seamont',
  'Other'
);

CREATE TYPE time_slot AS ENUM (
  '10:00 AM',
  '11:00 AM',
  '12:00 PM',
  '2:00 PM',
  '3:00 PM',
  '4:00 PM',
  '5:00 PM'
);

-- ─── Bookings Table ───────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS bookings (
  -- Identity
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Lead Information
  full_name         TEXT NOT NULL CHECK (length(full_name) >= 2 AND length(full_name) <= 100),
  email             TEXT NOT NULL CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
  phone             TEXT NOT NULL CHECK (phone ~ '^[+]?[\d\s\-\(\)]{7,20}$'),

  -- Property & Schedule
  property_interest property_interest DEFAULT 'Other',
  preferred_date    DATE,
  preferred_time    time_slot,
  message           TEXT CHECK (length(message) <= 1000),

  -- Status & CRM
  status            booking_status NOT NULL DEFAULT 'new',
  assigned_to       TEXT,
  notes             TEXT,
  follow_up_date    DATE,

  -- Attribution
  source            TEXT DEFAULT 'website',
  utm_source        TEXT,
  utm_medium        TEXT,
  utm_campaign      TEXT,
  ip_address        INET, -- For deduplication, stored anonymized

  -- Email & Webhook
  email_sent        BOOLEAN DEFAULT FALSE,
  webhook_triggered BOOLEAN DEFAULT FALSE,
  webhook_response  JSONB
);

-- ─── Indexes ──────────────────────────────────────────────────────────────────

CREATE INDEX idx_bookings_created_at    ON bookings(created_at DESC);
CREATE INDEX idx_bookings_status        ON bookings(status);
CREATE INDEX idx_bookings_email         ON bookings(email);
CREATE INDEX idx_bookings_property      ON bookings(property_interest);
CREATE INDEX idx_bookings_follow_up     ON bookings(follow_up_date) WHERE follow_up_date IS NOT NULL;

-- ─── Updated At Trigger ────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER bookings_updated_at
  BEFORE UPDATE ON bookings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ─── Row Level Security ───────────────────────────────────────────────────────

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Policy: Anonymous users can INSERT bookings (from the form)
CREATE POLICY "bookings_insert_anonymous"
  ON bookings
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Policy: Authenticated users (CRM staff) can read all bookings
CREATE POLICY "bookings_read_authenticated"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy: Authenticated users can update bookings (CRM workflow)
CREATE POLICY "bookings_update_authenticated"
  ON bookings
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ─── Analytics View ────────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW booking_analytics AS
SELECT
  DATE_TRUNC('day', created_at) AS day,
  property_interest,
  status,
  COUNT(*) AS count,
  COUNT(*) FILTER (WHERE email_sent = true) AS emails_sent,
  COUNT(*) FILTER (WHERE webhook_triggered = true) AS webhooks_fired,
  utm_source,
  utm_medium,
  utm_campaign
FROM bookings
GROUP BY 1, 2, 3, 8, 9, 10
ORDER BY 1 DESC;

-- ─── Sample Data (Remove in Production) ───────────────────────────────────────

-- INSERT INTO bookings (full_name, email, phone, property_interest, preferred_date, preferred_time, message)
-- VALUES
--   ('Rahul Mehta', 'rahul.mehta@example.com', '+91 98765 43210', 'World One', '2025-03-15', '2:00 PM', 'Interested in penthouse floors'),
--   ('Priya Sharma', 'priya@example.com', '+91 87654 32109', 'Lodha Malabar', '2025-03-20', '11:00 AM', 'Looking for 4BHK');
