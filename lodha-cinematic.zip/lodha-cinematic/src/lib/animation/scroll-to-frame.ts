// ─────────────────────────────────────────────────────────────────────────────
// SCROLL-TO-FRAME MAPPING UTILITY
// Production-grade frame index calculation with easing, clamping, and lerp
// ─────────────────────────────────────────────────────────────────────────────

import type { EasingFunction, FrameSequenceConfig } from '@/types';

// ─── Easing Functions ────────────────────────────────────────────────────────

/**
 * Linear — no easing, direct mapping
 */
export const linear: EasingFunction = (t) => t;

/**
 * Ease in quad — gentle acceleration
 */
export const easeInQuad: EasingFunction = (t) => t * t;

/**
 * Ease out quad — gentle deceleration
 */
export const easeOutQuad: EasingFunction = (t) => t * (2 - t);

/**
 * Ease in out quad — smooth symmetric
 */
export const easeInOutQuad: EasingFunction = (t) =>
  t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;

/**
 * Ease in out cubic — luxury cinematic feel
 */
export const easeInOutCubic: EasingFunction = (t) =>
  t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;

/**
 * Ease out expo — dramatic deceleration
 */
export const easeOutExpo: EasingFunction = (t) =>
  t === 1 ? 1 : 1 - Math.pow(2, -10 * t);

/**
 * Ease in out sine — ultra-smooth cinematic
 */
export const easeInOutSine: EasingFunction = (t) =>
  -(Math.cos(Math.PI * t) - 1) / 2;

/**
 * Custom luxury ease — slow start, held mid, slow end
 * Perfect for cinematic scroll storytelling
 */
export const luxuryEase: EasingFunction = (t) => {
  // Bezier approximation: cubic-bezier(0.25, 0.1, 0.25, 1.0)
  const p0 = 0, p1 = 0.1, p2 = 0.25, p3 = 1.0;
  return (
    3 * Math.pow(1 - t, 2) * t * p1 +
    3 * (1 - t) * Math.pow(t, 2) * p2 +
    Math.pow(t, 3) * p3
  );
};

// ─── Math Utilities ───────────────────────────────────────────────────────────

/**
 * Clamp value between min and max
 */
export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

/**
 * Linear interpolation between two values
 */
export function lerp(start: number, end: number, t: number): number {
  return start + (end - start) * t;
}

/**
 * Inverse lerp — returns t value given a value between start and end
 */
export function inverseLerp(start: number, end: number, value: number): number {
  if (Math.abs(end - start) < 1e-10) return 0;
  return clamp((value - start) / (end - start), 0, 1);
}

/**
 * Map a value from one range to another
 */
export function mapRange(
  value: number,
  inMin: number,
  inMax: number,
  outMin: number,
  outMax: number
): number {
  const t = inverseLerp(inMin, inMax, value);
  return lerp(outMin, outMax, t);
}

/**
 * Smooth damp — follows target with spring-like damping
 * Useful for canvas frame smoothing
 */
export function smoothDamp(
  current: number,
  target: number,
  velocity: { value: number },
  smoothTime: number,
  maxSpeed = Infinity,
  deltaTime = 1 / 60
): number {
  smoothTime = Math.max(0.0001, smoothTime);
  const omega = 2 / smoothTime;
  const x = omega * deltaTime;
  const exp = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
  let diff = current - target;
  const originalTo = target;
  const maxDelta = maxSpeed * smoothTime;
  diff = clamp(diff, -maxDelta, maxDelta);
  target = current - diff;
  const temp = (velocity.value + omega * diff) * deltaTime;
  velocity.value = (velocity.value - omega * temp) * exp;
  let output = target + (diff + temp) * exp;
  if (originalTo - current > 0 === output > originalTo) {
    output = originalTo;
    velocity.value = (output - originalTo) / deltaTime;
  }
  return output;
}

// ─── Frame Calculation ───────────────────────────────────────────────────────

export interface FrameCalculationOptions {
  /** Raw scroll progress 0–1 */
  scrollProgress: number;
  /** Total frame count */
  totalFrames: number;
  /** Optional easing function */
  ease?: EasingFunction;
  /** Optional start range within the 0–1 scroll window */
  progressStart?: number;
  /** Optional end range within the 0–1 scroll window */
  progressEnd?: number;
  /** Whether to snap to integer frames (default: false for blending) */
  snap?: boolean;
}

/**
 * Core frame index calculation function
 * Maps normalized scroll progress to a frame index
 * 
 * @example
 * // Map scroll progress to frame index for a 120-frame sequence
 * const frame = scrollProgressToFrame({
 *   scrollProgress: 0.45,
 *   totalFrames: 120,
 *   ease: easeInOutCubic,
 * });
 * // → Returns floating point frame index (e.g., 53.7)
 * // → Use Math.round() or Math.floor() depending on blending strategy
 */
export function scrollProgressToFrame({
  scrollProgress,
  totalFrames,
  ease = easeInOutSine,
  progressStart = 0,
  progressEnd = 1,
  snap = true,
}: FrameCalculationOptions): number {
  // Remap progress to the sub-range
  const remapped = inverseLerp(progressStart, progressEnd, scrollProgress);

  // Apply easing
  const eased = ease(clamp(remapped, 0, 1));

  // Map to frame index (0 to totalFrames - 1)
  const frameFloat = eased * (totalFrames - 1);

  // Return snapped or floating
  return snap ? Math.round(clamp(frameFloat, 0, totalFrames - 1)) : clamp(frameFloat, 0, totalFrames - 1);
}

/**
 * Calculate frame index from DOM position
 * Uses the sticky container's scroll position
 * 
 * @param container - The sticky wrapper element
 * @param config - Frame sequence configuration
 * @returns Calculated frame index
 */
export function getFrameFromScrollPosition(
  container: HTMLElement,
  config: FrameSequenceConfig
): { frameIndex: number; progress: number } {
  const rect = container.getBoundingClientRect();
  const containerHeight = container.offsetHeight;
  const viewportHeight = window.innerHeight;

  // How far we've scrolled INTO this section
  // When rect.top = viewportHeight, progress = 0 (just entered)
  // When rect.top = viewportHeight - containerHeight, progress = 1 (fully exited)
  const scrolled = viewportHeight - rect.top;
  const total = containerHeight - viewportHeight;

  const progress = clamp(scrolled / total, 0, 1);

  const frameIndex = scrollProgressToFrame({
    scrollProgress: progress,
    totalFrames: config.totalFrames,
    ease: easeInOutSine,
    snap: true,
  });

  return { frameIndex, progress };
}

/**
 * Get normalized progress for a specific section
 * Used to detect which section is "active" and at what stage
 */
export function getSectionProgress(
  currentProgress: number,
  sectionIndex: number,
  totalSections: number
): number {
  const sectionSize = 1 / totalSections;
  const sectionStart = sectionIndex * sectionSize;
  const sectionEnd = sectionStart + sectionSize;

  return clamp(
    inverseLerp(sectionStart, sectionEnd, currentProgress),
    0,
    1
  );
}

/**
 * Generate frame filename with zero-padded index
 * 
 * @example
 * getFramePath('/frames/section1', 47, 'webp', 3)
 * → '/frames/section1/frame_047.webp'
 */
export function getFramePath(
  basePath: string,
  frameIndex: number,
  format: string,
  padding: number = 4
): string {
  const padded = String(frameIndex).padStart(padding, '0');
  return `${basePath}/frame_${padded}.${format}`;
}

/**
 * Generate array of all frame paths for a sequence
 */
export function generateFramePaths(config: FrameSequenceConfig): string[] {
  return Array.from({ length: config.totalFrames }, (_, i) =>
    getFramePath(
      config.framesPath,
      config.startFrame + i,
      config.frameFormat,
      4
    )
  );
}

/**
 * Determine text overlay opacity based on scroll progress
 * Creates a fade-in / hold / fade-out curve
 */
export function getTextOpacity(
  progress: number,
  fadeInStart = 0.1,
  fadeInEnd = 0.25,
  fadeOutStart = 0.75,
  fadeOutEnd = 0.9
): number {
  if (progress < fadeInStart) return 0;
  if (progress < fadeInEnd) return inverseLerp(fadeInStart, fadeInEnd, progress);
  if (progress < fadeOutStart) return 1;
  if (progress < fadeOutEnd) return 1 - inverseLerp(fadeOutStart, fadeOutEnd, progress);
  return 0;
}

/**
 * Parallax offset calculation
 * Returns translate Y values for layered parallax effects
 */
export function getParallaxOffset(
  progress: number,
  speed: number = 0.5,
  maxOffset: number = 100
): number {
  return clamp((progress - 0.5) * maxOffset * speed, -maxOffset, maxOffset);
}
