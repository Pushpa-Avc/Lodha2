// ─────────────────────────────────────────────────────────────────────────────
// FRAME PRELOADER
// High-performance image sequence preloader with:
// - Priority queue loading (first 10 frames first)
// - Concurrent loading with configurable parallelism
// - Progress tracking
// - Memory-aware loading
// - Lazy section loading
// ─────────────────────────────────────────────────────────────────────────────

import type { FrameSequenceConfig, FramePreloaderState } from '@/types';
import { generateFramePaths } from './scroll-to-frame';

// ─── Constants ───────────────────────────────────────────────────────────────

const DEFAULT_CONCURRENCY = 6; // Browser connection pool limit per domain
const PRIORITY_BATCH_SIZE = 12; // First N frames loaded with highest priority
const MEMORY_THRESHOLD_MB = 200; // Warn if estimated memory exceeds this

// ─── Types ───────────────────────────────────────────────────────────────────

type ProgressCallback = (state: FramePreloaderState) => void;
type CompleteCallback = (frames: HTMLImageElement[]) => void;
type ErrorCallback = (error: Error, path: string) => void;

export interface PreloaderOptions {
  onProgress?: ProgressCallback;
  onComplete?: CompleteCallback;
  onError?: ErrorCallback;
  concurrency?: number;
  retries?: number;
  retryDelay?: number;
  priorityFrames?: number; // Number of priority frames to load first
  abortSignal?: AbortSignal;
}

// ─── Core Preloader Class ────────────────────────────────────────────────────

export class FramePreloader {
  private frames: HTMLImageElement[] = [];
  private loadedCount: number = 0;
  private totalFrames: number = 0;
  private isPaused: boolean = false;
  private isAborted: boolean = false;
  private options: Required<Omit<PreloaderOptions, 'abortSignal'>>;
  private abortSignal?: AbortSignal;

  constructor(options: PreloaderOptions = {}) {
    this.options = {
      onProgress: options.onProgress ?? (() => {}),
      onComplete: options.onComplete ?? (() => {}),
      onError: options.onError ?? (() => {}),
      concurrency: options.concurrency ?? DEFAULT_CONCURRENCY,
      retries: options.retries ?? 2,
      retryDelay: options.retryDelay ?? 500,
      priorityFrames: options.priorityFrames ?? PRIORITY_BATCH_SIZE,
    };
    this.abortSignal = options.abortSignal;
  }

  /**
   * Load a single image with retry logic
   */
  private async loadImage(src: string, index: number): Promise<HTMLImageElement> {
    let lastError: Error = new Error('Failed to load');

    for (let attempt = 0; attempt <= this.options.retries; attempt++) {
      if (this.isAborted) throw new Error('Preloader aborted');

      try {
        const img = await this.createImageElement(src);
        this.frames[index] = img;
        this.loadedCount++;
        this.reportProgress();
        return img;
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));

        if (attempt < this.options.retries) {
          await this.delay(this.options.retryDelay * (attempt + 1));
        }
      }
    }

    this.options.onError(lastError, src);
    throw lastError;
  }

  /**
   * Create Image element and wait for load
   */
  private createImageElement(src: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      if (this.isAborted) {
        reject(new Error('Preloader aborted'));
        return;
      }

      const img = new Image();

      // Performance hints
      img.decoding = 'async';
      img.loading = 'eager';

      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error(`Failed to load: ${src}`));

      img.src = src;
    });
  }

  /**
   * Load frames in batches with controlled concurrency
   */
  private async loadBatch(
    paths: string[],
    startIndex: number
  ): Promise<void> {
    const { concurrency } = this.options;
    const results: Promise<HTMLImageElement>[] = [];
    let i = 0;

    // Sliding window concurrency control
    const execute = async (): Promise<void> => {
      if (i >= paths.length || this.isAborted) return;

      const currentIndex = i++;
      const globalIndex = startIndex + currentIndex;

      await this.loadImage(paths[currentIndex], globalIndex).catch(() => {
        // Silently fail individual frames — use placeholder
        this.loadedCount++;
        this.reportProgress();
      });

      await execute();
    };

    for (let w = 0; w < Math.min(concurrency, paths.length); w++) {
      results.push(execute() as unknown as Promise<HTMLImageElement>);
    }

    await Promise.all(results);
  }

  /**
   * Main load method — loads priority frames first, then remainder
   */
  async load(config: FrameSequenceConfig): Promise<HTMLImageElement[]> {
    const paths = generateFramePaths(config);
    this.totalFrames = paths.length;
    this.loadedCount = 0;
    this.frames = new Array(paths.length).fill(null);
    this.isAborted = false;

    // Log memory estimate
    const estimatedMemoryMB = this.estimateMemoryUsage(
      config.width,
      config.height,
      paths.length
    );

    if (estimatedMemoryMB > MEMORY_THRESHOLD_MB) {
      console.warn(
        `[FramePreloader] Estimated memory usage ${estimatedMemoryMB.toFixed(0)}MB ` +
        `exceeds threshold of ${MEMORY_THRESHOLD_MB}MB. Consider reducing frame count or resolution.`
      );
    }

    // Phase 1: Load priority frames immediately
    const priorityCount = Math.min(this.options.priorityFrames, paths.length);
    const priorityPaths = paths.slice(0, priorityCount);
    const remainderPaths = paths.slice(priorityCount);

    await this.loadBatch(priorityPaths, 0);

    // Phase 2: Load remaining frames in background
    if (remainderPaths.length > 0 && !this.isAborted) {
      await this.loadBatch(remainderPaths, priorityCount);
    }

    if (!this.isAborted) {
      this.options.onComplete(this.frames);
    }

    return this.frames;
  }

  /**
   * Abort in-progress loading
   */
  abort(): void {
    this.isAborted = true;
  }

  /**
   * Get current progress state
   */
  getState(): FramePreloaderState {
    return {
      loaded: this.loadedCount,
      total: this.totalFrames,
      progress: this.totalFrames > 0 ? this.loadedCount / this.totalFrames : 0,
      isComplete: this.loadedCount >= this.totalFrames && this.totalFrames > 0,
      error: null,
      frames: this.frames,
    };
  }

  /**
   * Report progress to callback
   */
  private reportProgress(): void {
    this.options.onProgress(this.getState());
  }

  /**
   * Estimate GPU/CPU memory usage
   * WebP: ~4 bytes per pixel decoded in memory (RGBA)
   */
  private estimateMemoryUsage(
    width: number,
    height: number,
    frameCount: number
  ): number {
    const bytesPerFrame = width * height * 4;
    const totalBytes = bytesPerFrame * frameCount;
    return totalBytes / (1024 * 1024);
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

// ─── Singleton Manager ───────────────────────────────────────────────────────

/**
 * PreloaderManager — manages multiple section preloaders
 * Implements lazy loading: only preloads next section when current is 70% scrolled
 */
export class PreloaderManager {
  private preloaders: Map<string, FramePreloader> = new Map();
  private loadedSections: Set<string> = new Set();
  private frameCache: Map<string, HTMLImageElement[]> = new Map();

  /**
   * Preload a section's frames
   */
  async preloadSection(
    config: FrameSequenceConfig,
    options?: PreloaderOptions
  ): Promise<HTMLImageElement[]> {
    const key = config.id;

    // Return cached if already loaded
    if (this.frameCache.has(key)) {
      return this.frameCache.get(key)!;
    }

    // Abort existing load if any
    if (this.preloaders.has(key)) {
      this.preloaders.get(key)!.abort();
    }

    const preloader = new FramePreloader(options);
    this.preloaders.set(key, preloader);

    const frames = await preloader.load(config);
    this.frameCache.set(key, frames);
    this.loadedSections.add(key);

    return frames;
  }

  /**
   * Get frames for a section (or null if not loaded)
   */
  getFrames(sectionId: string): HTMLImageElement[] | null {
    return this.frameCache.get(sectionId) ?? null;
  }

  /**
   * Check if a section is loaded
   */
  isSectionLoaded(sectionId: string): boolean {
    return this.loadedSections.has(sectionId);
  }

  /**
   * Clear a section from cache (memory management)
   */
  clearSection(sectionId: string): void {
    this.frameCache.delete(sectionId);
    this.loadedSections.delete(sectionId);
  }

  /**
   * Clear all cache
   */
  clearAll(): void {
    this.preloaders.forEach((p) => p.abort());
    this.preloaders.clear();
    this.frameCache.clear();
    this.loadedSections.clear();
  }
}

// ─── Global Instance ─────────────────────────────────────────────────────────

export const globalPreloaderManager = new PreloaderManager();

// ─── React Hook ──────────────────────────────────────────────────────────────

import { useState, useEffect, useRef } from 'react';

export function useFramePreloader(config: FrameSequenceConfig | null) {
  const [state, setState] = useState<FramePreloaderState>({
    loaded: 0,
    total: 0,
    progress: 0,
    isComplete: false,
    error: null,
    frames: [],
  });

  const preloaderRef = useRef<FramePreloader | null>(null);

  useEffect(() => {
    if (!config) return;

    let cancelled = false;

    const preloader = new FramePreloader({
      onProgress: (s) => {
        if (!cancelled) setState(s);
      },
      onComplete: (frames) => {
        if (!cancelled) {
          setState((prev) => ({ ...prev, isComplete: true, frames }));
        }
      },
      onError: (error) => {
        if (!cancelled) {
          setState((prev) => ({ ...prev, error: error.message }));
        }
      },
      priorityFrames: 15,
    });

    preloaderRef.current = preloader;
    preloader.load(config);

    return () => {
      cancelled = true;
      preloader.abort();
    };
  }, [config?.id]);

  return state;
}
