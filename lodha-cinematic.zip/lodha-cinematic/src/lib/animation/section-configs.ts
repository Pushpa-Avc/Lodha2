// ─────────────────────────────────────────────────────────────────────────────
// SECTION CONFIGURATIONS
// Frame sequence configs for all 5 cinematic sections
// ─────────────────────────────────────────────────────────────────────────────

import type { FrameSequenceConfig } from '@/types';

/**
 * SECTION CONFIGURATIONS
 * 
 * Frame Generation Notes:
 * ─────────────────────────────────────────────────────────────────────────────
 * Section 1 — ARRIVAL (Interior → Window Camera Push)
 *   Tool: Blender / Unreal Engine 5
 *   Render: 100 frames at 1920×1080, golden hour lighting
 *   Camera: Slow dolly forward, 4mm lens, 10m travel distance
 *   Output: /public/frames/section1/frame_0000.webp → frame_0099.webp
 * 
 * Section 2 — SKYLINE REVEAL (Glass pass-through → Mumbai horizon)
 *   Tool: Blender with compositor glass shader
 *   Render: 90 frames — glass opacity 100% → 0%, skyline fade in
 *   Output: /public/frames/section2/frame_0000.webp → frame_0089.webp
 * 
 * Section 3 — TOWER FOCUS (Skyscraper orbital rotation)
 *   Tool: Blender orbital camera rig
 *   Render: 120 frames — 240° rotation with sunset rim light shift
 *   Output: /public/frames/section3/frame_0000.webp → frame_0119.webp
 * 
 * Section 4 — ARCHITECTURAL TRANSFORMATION (Solid → Wireframe)
 *   Tool: Blender geometry nodes — vertex-driven wireframe morph
 *   Render: 100 frames — material opacity blend, gold wireframe emergence
 *   Output: /public/frames/section4/frame_0000.webp → frame_0099.webp
 * 
 * Section 5 — GLOBAL VISION (Wireframe → Particles → Earth)
 *   Tool: Blender particles + Earth geometry with city lights emission
 *   Render: 120 frames — dissolve to particle cloud, reform as globe
 *   Output: /public/frames/section5/frame_0000.webp → frame_0119.webp
 * 
 * ─────────────────────────────────────────────────────────────────────────────
 * PLACEHOLDER NOTE:
 * Until production assets are rendered, place placeholder WebP images in each
 * frame directory. Use the script: npm run frames:convert to batch-convert
 * from source formats (PNG/JPG) to WebP.
 * ─────────────────────────────────────────────────────────────────────────────
 */

export const SECTION_CONFIGS: FrameSequenceConfig[] = [
  // ─── Section 1: Arrival ──────────────────────────────────────────────────
  {
    id: 'section-1-arrival',
    section: 1,
    framesPath: '/frames/section1',
    frameFormat: 'webp',
    totalFrames: 100,
    startFrame: 0,
    endFrame: 99,
    width: 1920,
    height: 1080,
    scrollHeight: 400, // 400vh sticky height
    content: {
      headline: 'Arrive Above the Ordinary.',
      subheadline: 'Mumbai's finest address begins here.',
      body: 'From the moment you enter, the city falls silent beneath you.',
      revealAt: 0.08,
      hideAt: 0.82,
      align: 'left',
      position: 'bottom',
    },
  },

  // ─── Section 2: Skyline Reveal ───────────────────────────────────────────
  {
    id: 'section-2-skyline',
    section: 2,
    framesPath: '/frames/section2',
    frameFormat: 'webp',
    totalFrames: 90,
    startFrame: 0,
    endFrame: 89,
    width: 1920,
    height: 1080,
    scrollHeight: 400,
    content: {
      headline: 'Where Mumbai\nMeets the Sky.',
      subheadline: 'A horizon that redefines expectation.',
      body: 'Every sunset is different. Every view, entirely yours.',
      revealAt: 0.12,
      hideAt: 0.85,
      align: 'center',
      position: 'center',
    },
  },

  // ─── Section 3: Tower Focus ───────────────────────────────────────────────
  {
    id: 'section-3-tower',
    section: 3,
    framesPath: '/frames/section3',
    frameFormat: 'webp',
    totalFrames: 120,
    startFrame: 0,
    endFrame: 119,
    width: 1920,
    height: 1080,
    scrollHeight: 450,
    content: {
      headline: 'Architecture\nas a Statement.',
      subheadline: 'Standing singular on the city's crown.',
      body: 'Forty years of precision. One building that defines a skyline.',
      revealAt: 0.15,
      hideAt: 0.8,
      align: 'right',
      position: 'center',
    },
  },

  // ─── Section 4: Architectural Transformation ──────────────────────────────
  {
    id: 'section-4-blueprint',
    section: 4,
    framesPath: '/frames/section4',
    frameFormat: 'webp',
    totalFrames: 100,
    startFrame: 0,
    endFrame: 99,
    width: 1920,
    height: 1080,
    scrollHeight: 400,
    content: {
      headline: 'Precision\nin Every Line.',
      subheadline: 'Engineered with intention. Designed without compromise.',
      body: 'Behind every curve, a decision. Behind every decision, mastery.',
      revealAt: 0.1,
      hideAt: 0.85,
      align: 'left',
      position: 'bottom',
    },
  },

  // ─── Section 5: Global Vision ─────────────────────────────────────────────
  {
    id: 'section-5-global',
    section: 5,
    framesPath: '/frames/section5',
    frameFormat: 'webp',
    totalFrames: 120,
    startFrame: 0,
    endFrame: 119,
    width: 1920,
    height: 1080,
    scrollHeight: 450,
    content: {
      headline: 'Built for a\nGlobal Standard.',
      subheadline: 'From Mumbai to the world.',
      body: 'Lodha. Redefining what a home means for those who inhabit the extraordinary.',
      revealAt: 0.1,
      hideAt: 0.9,
      align: 'center',
      position: 'center',
      cta: {
        label: 'Schedule a Private Viewing',
        action: 'modal',
        variant: 'primary',
      },
    },
  },
];

// ─── Totals ───────────────────────────────────────────────────────────────────

export const TOTAL_FRAMES = SECTION_CONFIGS.reduce(
  (sum, c) => sum + c.totalFrames,
  0
);

export const TOTAL_SCROLL_HEIGHT = SECTION_CONFIGS.reduce(
  (sum, c) => sum + c.scrollHeight,
  0
);

console.info(
  `[Sections] ${SECTION_CONFIGS.length} sections, ` +
  `${TOTAL_FRAMES} total frames, ` +
  `${TOTAL_SCROLL_HEIGHT}vh total scroll height`
);
