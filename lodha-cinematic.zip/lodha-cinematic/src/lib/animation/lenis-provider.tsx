'use client';

// ─────────────────────────────────────────────────────────────────────────────
// LENIS SMOOTH SCROLL PROVIDER
// Global smooth scroll context using @studio-freight/lenis
// ─────────────────────────────────────────────────────────────────────────────

import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import Lenis from '@studio-freight/lenis';

// ─── Context ─────────────────────────────────────────────────────────────────

interface LenisContextValue {
  lenis: Lenis | null;
  scrollY: number;
  scrollProgress: number;
}

const LenisContext = createContext<LenisContextValue>({
  lenis: null,
  scrollY: 0,
  scrollProgress: 0,
});

// ─── Provider ─────────────────────────────────────────────────────────────────

interface LenisProviderProps {
  children: ReactNode;
  /** Scroll speed multiplier — lower = slower, more cinematic */
  lerp?: number;
  /** Smooth duration in seconds */
  duration?: number;
  /** Disable on mobile (native feels better) */
  disableOnMobile?: boolean;
}

export function LenisProvider({
  children,
  lerp = 0.07,   // 0.07 = very smooth, cinematic feel
  duration = 1.2,
  disableOnMobile = true,
}: LenisProviderProps) {
  const [scrollY, setScrollY] = useState(0);
  const [scrollProgress, setScrollProgress] = useState(0);
  const lenisRef = useRef<Lenis | null>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    // Respect reduced-motion preference
    const prefersReducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    // Check if mobile
    const isMobile = window.innerWidth < 768;

    if (prefersReducedMotion || (disableOnMobile && isMobile)) {
      return; // Use native scroll
    }

    // Initialize Lenis
    const lenis = new Lenis({
      lerp,
      duration,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)), // Expo ease out
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      touchMultiplier: 2,
      infinite: false,
    });

    lenisRef.current = lenis;

    // Track scroll values
    lenis.on('scroll', ({ scroll, progress }: { scroll: number; progress: number }) => {
      setScrollY(scroll);
      setScrollProgress(progress);
    });

    // RAF loop
    function raf(time: number) {
      lenis.raf(time);
      rafRef.current = requestAnimationFrame(raf);
    }

    rafRef.current = requestAnimationFrame(raf);

    return () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
      }
      lenis.destroy();
      lenisRef.current = null;
    };
  }, [lerp, duration, disableOnMobile]);

  return (
    <LenisContext.Provider
      value={{
        lenis: lenisRef.current,
        scrollY,
        scrollProgress,
      }}
    >
      {children}
    </LenisContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useLenis() {
  return useContext(LenisContext);
}

/**
 * Programmatically scroll to a section by index
 */
export function useScrollTo() {
  const { lenis } = useLenis();

  return function scrollTo(
    target: string | HTMLElement | number,
    options?: { offset?: number; duration?: number; immediate?: boolean }
  ) {
    if (!lenis) {
      // Fallback to native scroll
      if (typeof target === 'string') {
        const el = document.querySelector(target);
        el?.scrollIntoView({ behavior: 'smooth' });
      } else if (typeof target === 'number') {
        window.scrollTo({ top: target, behavior: 'smooth' });
      }
      return;
    }

    lenis.scrollTo(target, {
      offset: options?.offset ?? 0,
      duration: options?.duration ?? 1.5,
      immediate: options?.immediate ?? false,
    });
  };
}
