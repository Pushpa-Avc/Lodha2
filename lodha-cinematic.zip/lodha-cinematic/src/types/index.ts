// ─────────────────────────────────────────────────────────────────────────────
// LODHA CINEMATIC — TYPE DEFINITIONS
// Production-grade TypeScript interfaces for entire application
// ─────────────────────────────────────────────────────────────────────────────

// ─── Scroll Sequence ─────────────────────────────────────────────────────────

export interface FrameSequenceConfig {
  /** Unique section identifier */
  id: string;
  /** Section number (1–5) */
  section: number;
  /** Directory path for frame images (relative to /public) */
  framesPath: string;
  /** File format of frames */
  frameFormat: 'webp' | 'jpg' | 'png';
  /** Total number of frames in sequence */
  totalFrames: number;
  /** Zero-based first frame index */
  startFrame: number;
  /** Zero-based last frame index */
  endFrame: number;
  /** Desired render width */
  width: number;
  /** Desired render height */
  height: number;
  /** Scroll height multiplier (vh units) */
  scrollHeight: number;
  /** Content overlay for this section */
  content?: SectionContent;
}

export interface SectionContent {
  headline: string;
  subheadline?: string;
  body?: string;
  cta?: CallToAction;
  /** Scroll progress (0–1) at which text appears */
  revealAt?: number;
  /** Scroll progress (0–1) at which text disappears */
  hideAt?: number;
  /** Text alignment */
  align?: 'left' | 'center' | 'right';
  /** Vertical position */
  position?: 'top' | 'center' | 'bottom';
}

export interface CallToAction {
  label: string;
  href?: string;
  action?: 'scroll' | 'modal' | 'link';
  variant?: 'primary' | 'secondary' | 'ghost';
}

export interface ScrollSequenceState {
  currentFrame: number;
  scrollProgress: number;
  isPlaying: boolean;
  isLoaded: boolean;
  loadProgress: number;
}

export interface FramePreloaderState {
  loaded: number;
  total: number;
  progress: number;
  isComplete: boolean;
  error: string | null;
  frames: HTMLImageElement[];
}

// ─── Canvas Renderer ──────────────────────────────────────────────────────────

export interface CanvasConfig {
  width: number;
  height: number;
  pixelRatio?: number;
  compositeOperation?: GlobalCompositeOperation;
  imageSmoothingEnabled?: boolean;
  imageSmoothingQuality?: ImageSmoothingQuality;
}

export interface RenderContext {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  frame: HTMLImageElement;
  progress: number;
  frameIndex: number;
  timestamp: number;
}

// ─── Animation System ────────────────────────────────────────────────────────

export type EasingFunction = (t: number) => number;

export interface ScrollTriggerConfig {
  trigger: HTMLElement | null;
  start: number | string;
  end: number | string;
  scrub?: boolean | number;
  pin?: boolean;
  onEnter?: () => void;
  onLeave?: () => void;
  onUpdate?: (progress: number) => void;
}

export interface TransitionConfig {
  duration: number;
  ease: EasingFunction | string;
  delay?: number;
  stagger?: number;
}

// ─── Booking / Lead Form ─────────────────────────────────────────────────────

export interface BookingFormData {
  full_name: string;
  email: string;
  phone: string;
  property_interest?: PropertyInterest;
  preferred_date?: string;
  preferred_time?: TimeSlot;
  message?: string;
  source?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
}

export type PropertyInterest =
  | 'Lodha Malabar'
  | 'Lodha Altamount'
  | 'Lodha Trump Tower'
  | 'World One'
  | 'Lodha Seamont'
  | 'Other';

export type TimeSlot =
  | '10:00 AM'
  | '11:00 AM'
  | '12:00 PM'
  | '2:00 PM'
  | '3:00 PM'
  | '4:00 PM'
  | '5:00 PM';

export interface BookingRecord extends BookingFormData {
  id: string;
  created_at: string;
  status: BookingStatus;
  assigned_to?: string;
  notes?: string;
  follow_up_date?: string;
}

export type BookingStatus = 'new' | 'contacted' | 'scheduled' | 'visited' | 'converted' | 'lost';

// ─── API Responses ────────────────────────────────────────────────────────────

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface BookingApiResponse extends ApiResponse<BookingRecord> {
  bookingId?: string;
  emailSent?: boolean;
  webhookTriggered?: boolean;
}

// ─── Navigation ──────────────────────────────────────────────────────────────

export interface NavItem {
  label: string;
  href: string;
  external?: boolean;
}

export interface NavigationState {
  isOpen: boolean;
  currentSection: number;
  scrollProgress: number;
  isDark: boolean;
}

// ─── Performance ─────────────────────────────────────────────────────────────

export interface PerformanceMetrics {
  fps: number;
  frameDrops: number;
  memoryUsage?: number;
  loadTime: number;
  ttfb: number;
  lcp?: number;
  fid?: number;
  cls?: number;
}

export interface LoadingState {
  phase: 'idle' | 'loading' | 'ready' | 'error';
  progress: number;
  message: string;
  sectionsLoaded: boolean[];
}

// ─── Supabase Database ───────────────────────────────────────────────────────

export interface Database {
  public: {
    Tables: {
      bookings: {
        Row: BookingRecord;
        Insert: Omit<BookingRecord, 'id' | 'created_at'>;
        Update: Partial<Omit<BookingRecord, 'id' | 'created_at'>>;
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: {
      booking_status: BookingStatus;
      property_interest: PropertyInterest;
      time_slot: TimeSlot;
    };
  };
}

// ─── Component Props ─────────────────────────────────────────────────────────

export interface ScrollSequenceProps {
  config: FrameSequenceConfig;
  className?: string;
  priority?: boolean;
  onSectionActive?: (section: number) => void;
}

export interface CanvasRendererProps {
  width: number;
  height: number;
  frames: HTMLImageElement[];
  currentFrame: number;
  className?: string;
  onRender?: (ctx: RenderContext) => void;
}

export interface SectionOverlayProps {
  content: SectionContent;
  scrollProgress: number;
  className?: string;
}

export interface LoadingScreenProps {
  state: LoadingState;
  onComplete?: () => void;
}

export interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultProperty?: PropertyInterest;
}
