#!/usr/bin/env node

/**
 * FRAME OPTIMIZATION SCRIPT
 * ─────────────────────────────────────────────────────────────────────────────
 * Converts raw render frames (PNG/JPG) to optimized WebP
 * Compresses to target quality while maintaining visual fidelity
 * 
 * Usage:
 *   node scripts/optimize-frames.js
 *   node scripts/optimize-frames.js --section=1
 *   node scripts/optimize-frames.js --quality=82
 * 
 * Prerequisites:
 *   npm install sharp imagemin imagemin-webp
 * ─────────────────────────────────────────────────────────────────────────────
 */

const sharp = require('sharp');
const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

// ─── Configuration ────────────────────────────────────────────────────────────

const CONFIG = {
  inputBase: path.join(__dirname, '../raw-frames'),
  outputBase: path.join(__dirname, '../public/frames'),

  sections: [
    { id: 1, name: 'section1', frames: 100 },
    { id: 2, name: 'section2', frames: 90 },
    { id: 3, name: 'section3', frames: 120 },
    { id: 4, name: 'section4', frames: 100 },
    { id: 5, name: 'section5', frames: 120 },
  ],

  // WebP quality: 75-85 is optimal for photographic content
  quality: parseInt(process.env.QUALITY ?? '80'),

  // Resize to max width (preserves aspect ratio)
  maxWidth: 1920,
  maxHeight: 1080,

  // Concurrency for parallel processing
  concurrency: 4,
};

// ─── CLI Args ─────────────────────────────────────────────────────────────────

const args = process.argv.slice(2).reduce((acc, arg) => {
  const [key, value] = arg.replace('--', '').split('=');
  acc[key] = value;
  return acc;
}, {});

const targetSection = args.section ? parseInt(args.section) : null;
const targetQuality = args.quality ? parseInt(args.quality) : CONFIG.quality;

// ─── Utilities ────────────────────────────────────────────────────────────────

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

async function processFrame(inputPath, outputPath, quality) {
  const inputStat = fs.statSync(inputPath);

  await sharp(inputPath)
    .resize(CONFIG.maxWidth, CONFIG.maxHeight, {
      fit: 'inside',      // Never upscale
      withoutEnlargement: true,
    })
    .webp({
      quality,
      effort: 4,           // 0 (fast) to 6 (slow, better compression)
      smartSubsample: true,
      nearLossless: false,
    })
    .toFile(outputPath);

  const outputStat = fs.statSync(outputPath);
  const savings = (1 - outputStat.size / inputStat.size) * 100;

  return {
    inputSize: inputStat.size,
    outputSize: outputStat.size,
    savings: savings.toFixed(1),
  };
}

async function processBatch(files, batchSize) {
  const results = [];
  for (let i = 0; i < files.length; i += batchSize) {
    const batch = files.slice(i, i + batchSize);
    const batchResults = await Promise.all(batch.map((f) => f()));
    results.push(...batchResults);

    const progress = Math.min(i + batchSize, files.length);
    process.stdout.write(`  Progress: ${progress}/${files.length}\r`);
  }
  return results;
}

// ─── Main ─────────────────────────────────────────────────────────────────────

async function main() {
  console.log('\n🎬 Lodha Cinematic — Frame Optimizer');
  console.log('────────────────────────────────────────');
  console.log(`Quality: ${targetQuality}`);
  console.log(`Max size: ${CONFIG.maxWidth}×${CONFIG.maxHeight}`);
  console.log(`Concurrency: ${CONFIG.concurrency}`);
  console.log('');

  const sections = targetSection
    ? CONFIG.sections.filter((s) => s.id === targetSection)
    : CONFIG.sections;

  if (sections.length === 0) {
    console.error(`❌ Section ${targetSection} not found`);
    process.exit(1);
  }

  let totalInputSize = 0;
  let totalOutputSize = 0;
  let totalFrames = 0;

  for (const section of sections) {
    const inputDir = path.join(CONFIG.inputBase, section.name);
    const outputDir = path.join(CONFIG.outputBase, section.name);

    if (!fs.existsSync(inputDir)) {
      console.warn(`⚠️  Input directory not found: ${inputDir}`);
      console.warn(`   Create it and add your render frames as PNG/JPG files`);
      console.warn(`   Expected files: frame_0000.png → frame_${String(section.frames - 1).padStart(4, '0')}.png\n`);
      continue;
    }

    fs.mkdirSync(outputDir, { recursive: true });

    // Find source files
    const sourceFiles = fs
      .readdirSync(inputDir)
      .filter((f) => /\.(png|jpg|jpeg|tiff|tif)$/i.test(f))
      .sort();

    if (sourceFiles.length === 0) {
      console.warn(`⚠️  No source images found in ${inputDir}\n`);
      continue;
    }

    console.log(`📁 Section ${section.id}: ${section.name}`);
    console.log(`   Found ${sourceFiles.length} source frames`);

    const tasks = sourceFiles.map((file) => async () => {
      const inputPath = path.join(inputDir, file);
      const outputName = file.replace(/\.(png|jpg|jpeg|tiff|tif)$/i, '.webp');
      const outputPath = path.join(outputDir, outputName);

      // Skip if already converted and newer
      if (
        fs.existsSync(outputPath) &&
        fs.statSync(outputPath).mtime >= fs.statSync(inputPath).mtime
      ) {
        const stat = fs.statSync(outputPath);
        return { inputSize: stat.size, outputSize: stat.size, savings: '0' };
      }

      return processFrame(inputPath, outputPath, targetQuality);
    });

    const results = await processBatch(tasks, CONFIG.concurrency);

    const sectionInputSize = results.reduce((s, r) => s + r.inputSize, 0);
    const sectionOutputSize = results.reduce((s, r) => s + r.outputSize, 0);
    const sectionSavings = (1 - sectionOutputSize / sectionInputSize) * 100;

    console.log(`\n   ✅ ${results.length} frames processed`);
    console.log(`   Input:  ${formatBytes(sectionInputSize)}`);
    console.log(`   Output: ${formatBytes(sectionOutputSize)}`);
    console.log(`   Saved:  ${sectionSavings.toFixed(1)}%`);
    console.log('');

    totalInputSize += sectionInputSize;
    totalOutputSize += sectionOutputSize;
    totalFrames += results.length;
  }

  console.log('────────────────────────────────────────');
  console.log(`Total frames: ${totalFrames}`);
  console.log(`Total input:  ${formatBytes(totalInputSize)}`);
  console.log(`Total output: ${formatBytes(totalOutputSize)}`);
  console.log(
    `Total saved:  ${((1 - totalOutputSize / totalInputSize) * 100).toFixed(1)}%`
  );
  console.log('');
  console.log('✨ Optimization complete!');
  console.log('');
}

main().catch((err) => {
  console.error('❌ Error:', err.message);
  process.exit(1);
});
