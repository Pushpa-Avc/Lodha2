#!/usr/bin/env node

/**
 * PLACEHOLDER FRAME GENERATOR
 * ─────────────────────────────────────────────────────────────────────────────
 * Generates placeholder gradient frames for development/testing
 * so the site works before production 3D renders are ready.
 * 
 * Usage:
 *   node scripts/generate-placeholders.js
 * 
 * Prerequisites:
 *   npm install sharp
 * ─────────────────────────────────────────────────────────────────────────────
 */

const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

const SECTIONS = [
  {
    name: 'section1',
    frames: 100,
    startColor: [15, 12, 8],       // Dark warm interior
    endColor: [40, 30, 15],        // Golden hour glow
    text: 'ARRIVAL — Section 1',
  },
  {
    name: 'section2',
    frames: 90,
    startColor: [8, 15, 25],       // Deep evening sky
    endColor: [60, 40, 15],        // Sunset horizon
    text: 'SKYLINE REVEAL — Section 2',
  },
  {
    name: 'section3',
    frames: 120,
    startColor: [5, 5, 10],        // Dark building silhouette
    endColor: [20, 15, 8],         // Lit tower
    text: 'TOWER FOCUS — Section 3',
  },
  {
    name: 'section4',
    frames: 100,
    startColor: [8, 8, 8],         // Solid building
    endColor: [15, 12, 5],         // Wireframe gold
    text: 'BLUEPRINT — Section 4',
  },
  {
    name: 'section5',
    frames: 120,
    startColor: [2, 2, 8],         // Deep space black
    endColor: [5, 5, 20],          // Earth glow
    text: 'GLOBAL VISION — Section 5',
  },
];

function lerp(a, b, t) {
  return Math.round(a + (b - a) * t);
}

async function generateFrame(outputPath, width, height, r, g, b, frameNum, total, label) {
  // Create a gradient SVG
  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="g" cx="50%" cy="50%" r="70%">
          <stop offset="0%" stop-color="rgb(${r + 20},${g + 15},${b + 10})"/>
          <stop offset="100%" stop-color="rgb(${r},${g},${b})"/>
        </radialGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#g)"/>
      
      <!-- Gold center mark -->
      <circle cx="${width / 2}" cy="${height / 2}" r="2" fill="rgba(201,162,39,0.4)"/>
      
      <!-- Frame counter -->
      <text 
        x="${width / 2}" 
        y="${height - 40}" 
        font-family="monospace" 
        font-size="14" 
        fill="rgba(201,162,39,0.3)" 
        text-anchor="middle"
      >${label} · Frame ${String(frameNum).padStart(4, '0')}/${total - 1}</text>
      
      <!-- Progress bar -->
      <rect x="${width * 0.2}" y="${height - 20}" width="${width * 0.6}" height="1" fill="rgba(201,162,39,0.1)"/>
      <rect x="${width * 0.2}" y="${height - 20}" width="${width * 0.6 * (frameNum / (total - 1))}" height="1" fill="rgba(201,162,39,0.5)"/>
    </svg>
  `;

  await sharp(Buffer.from(svg))
    .resize(width, height)
    .webp({ quality: 60 })
    .toFile(outputPath);
}

async function main() {
  console.log('\n🎨 Lodha Cinematic — Placeholder Frame Generator');
  console.log('──────────────────────────────────────────────────');
  console.log('Generating development placeholder frames...\n');

  const W = 1920;
  const H = 1080;

  for (const section of SECTIONS) {
    const outputDir = path.join(__dirname, '../public/frames', section.name);
    fs.mkdirSync(outputDir, { recursive: true });

    console.log(`📁 ${section.name} — ${section.frames} frames`);

    let generated = 0;

    for (let i = 0; i < section.frames; i++) {
      const t = i / (section.frames - 1);
      const r = lerp(section.startColor[0], section.endColor[0], t);
      const g = lerp(section.startColor[1], section.endColor[1], t);
      const b = lerp(section.startColor[2], section.endColor[2], t);

      const filename = `frame_${String(i).padStart(4, '0')}.webp`;
      const outputPath = path.join(outputDir, filename);

      // Skip if exists
      if (fs.existsSync(outputPath)) {
        generated++;
        process.stdout.write(`  ${generated}/${section.frames}\r`);
        continue;
      }

      await generateFrame(outputPath, W, H, r, g, b, i, section.frames, section.text);
      generated++;
      process.stdout.write(`  ${generated}/${section.frames}\r`);
    }

    console.log(`  ✅ ${section.frames} placeholder frames generated`);
  }

  console.log('\n──────────────────────────────────────────────────');
  console.log('✨ All placeholder frames generated!');
  console.log('');
  console.log('📌 Next steps:');
  console.log('   1. Replace with real 3D renders when ready');
  console.log('   2. Run: npm run frames:optimize');
  console.log('   3. Push to Vercel: vercel --prod');
  console.log('');
}

main().catch(console.error);
