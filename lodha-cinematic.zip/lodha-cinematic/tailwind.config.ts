import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      // ─── Brand Colors ─────────────────────────────────────────────────
      colors: {
        brand: {
          black:      '#050505',
          charcoal:   '#0A0A0A',
          graphite:   '#111111',
          obsidian:   '#1A1A1A',
          smoke:      '#2A2A2A',
          ash:        '#3A3A3A',
          mist:       '#6B6B6B',
          silver:     '#9A9A9A',
          pearl:      '#D4D4D4',
          cream:      '#F5F5F5',
          white:      '#FFFFFF',
        },
        gold: {
          deep:       '#8B6914',
          warm:       '#B8860B',
          true:       '#C9A227',
          bright:     '#D4AF37',
          pale:       '#E8C96A',
          whisper:    '#F5E6A3',
        },
      },

      // ─── Typography ──────────────────────────────────────────────────
      fontFamily: {
        display:    ['Cormorant Garamond', 'Playfair Display', 'Georgia', 'serif'],
        serif:      ['Cormorant', 'Playfair Display', 'Georgia', 'serif'],
        sans:       ['Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'],
        mono:       ['JetBrains Mono', 'Courier New', 'monospace'],
        accent:     ['Cormorant Garamond', 'serif'],
      },

      fontSize: {
        '2xs':  ['0.625rem', { lineHeight: '1rem' }],
        'xs':   ['0.75rem',  { lineHeight: '1.25rem' }],
        'sm':   ['0.875rem', { lineHeight: '1.5rem' }],
        'base': ['1rem',     { lineHeight: '1.75rem' }],
        'lg':   ['1.125rem', { lineHeight: '2rem' }],
        'xl':   ['1.25rem',  { lineHeight: '2rem' }],
        '2xl':  ['1.5rem',   { lineHeight: '2.25rem' }],
        '3xl':  ['2rem',     { lineHeight: '2.5rem' }],
        '4xl':  ['2.5rem',   { lineHeight: '3rem' }],
        '5xl':  ['3.5rem',   { lineHeight: '4rem' }],
        '6xl':  ['5rem',     { lineHeight: '5.5rem' }],
        '7xl':  ['6rem',     { lineHeight: '6.5rem' }],
        '8xl':  ['8rem',     { lineHeight: '8.5rem' }],
        '9xl':  ['10rem',    { lineHeight: '10.5rem' }],
      },

      letterSpacing: {
        'ultra-tight': '-0.08em',
        'tight':       '-0.04em',
        'snug':        '-0.02em',
        'normal':      '0em',
        'wide':        '0.08em',
        'wider':       '0.15em',
        'widest':      '0.25em',
        'display':     '0.35em',
      },

      // ─── Spacing ──────────────────────────────────────────────────────
      spacing: {
        '18':  '4.5rem',
        '22':  '5.5rem',
        '26':  '6.5rem',
        '30':  '7.5rem',
        '34':  '8.5rem',
        '38':  '9.5rem',
        '42':  '10.5rem',
        '46':  '11.5rem',
        '50':  '12.5rem',
        '88':  '22rem',
        '100': '25rem',
        '112': '28rem',
        '128': '32rem',
        '144': '36rem',
        '160': '40rem',
        '192': '48rem',
        '256': '64rem',
      },

      // ─── Animation ───────────────────────────────────────────────────
      animation: {
        'fade-in':          'fadeIn 1.4s ease-out forwards',
        'fade-up':          'fadeUp 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'fade-down':        'fadeDown 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'slide-up':         'slideUp 1.6s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'slide-right':      'slideRight 1.4s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'gold-shimmer':     'goldShimmer 3s ease-in-out infinite',
        'text-reveal':      'textReveal 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'line-expand':      'lineExpand 1.4s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'particle-drift':   'particleDrift 8s ease-in-out infinite',
        'cursor-glow':      'cursorGlow 2s ease-in-out infinite',
        'breath':           'breath 4s ease-in-out infinite',
      },

      keyframes: {
        fadeIn: {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        fadeUp: {
          '0%':   { opacity: '0', transform: 'translateY(40px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeDown: {
          '0%':   { opacity: '0', transform: 'translateY(-40px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideUp: {
          '0%':   { transform: 'translateY(100%)' },
          '100%': { transform: 'translateY(0)' },
        },
        slideRight: {
          '0%':   { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(0)' },
        },
        goldShimmer: {
          '0%, 100%': { backgroundPosition: '200% center' },
          '50%':       { backgroundPosition: '-200% center' },
        },
        textReveal: {
          '0%':   { clipPath: 'inset(0 100% 0 0)' },
          '100%': { clipPath: 'inset(0 0% 0 0)' },
        },
        lineExpand: {
          '0%':   { scaleX: '0' },
          '100%': { scaleX: '1' },
        },
        particleDrift: {
          '0%, 100%': { transform: 'translate(0, 0) scale(1)' },
          '33%':       { transform: 'translate(10px, -15px) scale(1.05)' },
          '66%':       { transform: 'translate(-8px, 10px) scale(0.95)' },
        },
        cursorGlow: {
          '0%, 100%': { boxShadow: '0 0 10px rgba(201, 162, 39, 0.3)' },
          '50%':       { boxShadow: '0 0 30px rgba(201, 162, 39, 0.7)' },
        },
        breath: {
          '0%, 100%': { opacity: '0.6' },
          '50%':       { opacity: '1' },
        },
      },

      // ─── Transitions ─────────────────────────────────────────────────
      transitionTimingFunction: {
        'luxury':     'cubic-bezier(0.16, 1, 0.3, 1)',
        'cinematic':  'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        'dramatic':   'cubic-bezier(0.77, 0, 0.175, 1)',
        'silk':       'cubic-bezier(0.4, 0, 0.2, 1)',
      },

      transitionDuration: {
        '400':  '400ms',
        '600':  '600ms',
        '800':  '800ms',
        '1200': '1200ms',
        '1500': '1500ms',
        '2000': '2000ms',
        '3000': '3000ms',
      },

      // ─── Blur ─────────────────────────────────────────────────────────
      backdropBlur: {
        xs: '2px',
        sm: '4px',
        md: '8px',
        lg: '16px',
        xl: '24px',
        '2xl': '40px',
        '3xl': '64px',
      },

      // ─── Box Shadow ───────────────────────────────────────────────────
      boxShadow: {
        'gold-sm':    '0 2px 8px rgba(201, 162, 39, 0.15)',
        'gold-md':    '0 4px 24px rgba(201, 162, 39, 0.2)',
        'gold-lg':    '0 8px 48px rgba(201, 162, 39, 0.25)',
        'gold-xl':    '0 16px 80px rgba(201, 162, 39, 0.3)',
        'dark-sm':    '0 2px 16px rgba(0, 0, 0, 0.4)',
        'dark-md':    '0 8px 40px rgba(0, 0, 0, 0.6)',
        'dark-lg':    '0 20px 80px rgba(0, 0, 0, 0.8)',
        'inner-gold': 'inset 0 0 30px rgba(201, 162, 39, 0.1)',
      },

      // ─── Gradients ────────────────────────────────────────────────────
      backgroundImage: {
        'gold-linear':    'linear-gradient(135deg, #8B6914, #C9A227, #E8C96A, #C9A227, #8B6914)',
        'gold-radial':    'radial-gradient(ellipse at center, rgba(201, 162, 39, 0.2), transparent 70%)',
        'dark-vignette':  'radial-gradient(ellipse at center, transparent 40%, rgba(5, 5, 5, 0.8) 100%)',
        'hero-gradient':  'linear-gradient(to bottom, rgba(5,5,5,0) 0%, rgba(5,5,5,0.3) 50%, rgba(5,5,5,0.9) 100%)',
        'text-gradient':  'linear-gradient(135deg, #F5F5F5 0%, #C9A227 50%, #F5F5F5 100%)',
        'noise':          "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.05'/%3E%3C/svg%3E\")",
      },

      // ─── Aspect Ratios ────────────────────────────────────────────────
      aspectRatio: {
        'cinema':    '21 / 9',
        'wide':      '16 / 9',
        'classic':   '4 / 3',
        'square':    '1 / 1',
        'portrait':  '3 / 4',
      },

      // ─── Z-Index ──────────────────────────────────────────────────────
      zIndex: {
        '1':   '1',
        '2':   '2',
        '3':   '3',
        '60':  '60',
        '70':  '70',
        '80':  '80',
        '90':  '90',
        '100': '100',
        '999': '999',
      },
    },
  },
  plugins: [],
};

export default config;
