# Lodha Cinematic — Production Architecture

> A scroll-driven, frame-sequence cinematic website for Lodha Group.  
> Ultra-premium · Dark Luxury · Architecturally Sophisticated

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Tech Stack](#tech-stack)
3. [Project Structure](#project-structure)
4. [Cinematic System](#cinematic-system)
5. [Phase 1: Setup](#phase-1-setup)
6. [Phase 2: Assets](#phase-2-assets)
7. [Phase 3: Supabase](#phase-3-supabase)
8. [Phase 4: Deployment](#phase-4-deployment)
9. [Performance Checklist](#performance-checklist)
10. [Future Roadmap](#future-roadmap)

---

## Architecture Overview

```
Browser
  │
  ▼
┌─────────────────────────────────────────────────────────┐
│  Next.js 14 (App Router)                                │
│                                                         │
│  ┌─────────────┐   ┌──────────────────────────────────┐ │
│  │  Lenis       │   │  5 × ScrollSequence Components   │ │
│  │  (scroll)    │──▶│  Each: sticky + canvas + frames  │ │
│  └─────────────┘   └──────────────────────────────────┘ │
│                                │                         │
│                    ┌───────────▼──────────────────────┐  │
│                    │  FramePreloader                   │  │
│                    │  - Priority batch (first 15 frames│  │
│                    │  - Concurrent: 6 parallel loads   │  │
│                    │  - Lazy: next section on scroll   │  │
│                    └───────────────────────────────────┘  │
│                                                         │
│  ┌─────────────────────┐  ┌──────────────────────────┐  │
│  │  Framer Motion       │  │  Tailwind CSS             │  │
│  │  (text overlays)     │  │  (luxury design tokens)  │  │
│  └─────────────────────┘  └──────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────────┐
│  API Routes (Next.js)                                   │
│  POST /api/bookings → Supabase + Make.com Webhook       │
└─────────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────┐    ┌──────────────────────────────┐
│  Supabase             │    │  Make.com                    │
│  - bookings table     │───▶│  - Email confirmation        │
│  - RLS policies       │    │  - CRM notification          │
└─────────────────────┘    │  - Slack alert               │
                            └──────────────────────────────┘
```

---

## Tech Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| Framework | Next.js | 14.2 | App Router, SSR, API routes |
| Language | TypeScript | 5.4 | Type safety |
| Styling | Tailwind CSS | 3.4 | Utility-first luxury tokens |
| Animation | Framer Motion | 11 | Text overlays, transitions |
| Scroll | Lenis | 1.0.45 | Cinematic smooth scroll |
| Canvas | HTML5 Canvas API | — | Frame-by-frame rendering |
| Database | Supabase | 2.43 | Lead capture storage |
| Deployment | Vercel | — | Edge CDN deployment |
| Images | WebP (Sharp) | — | Optimized frame assets |

---

## Project Structure

```
lodha-cinematic/
├── src/
│   ├── app/
│   │   ├── layout.tsx              # Root layout (fonts, metadata, Lenis)
│   │   ├── page.tsx                # Home page (experience orchestrator)
│   │   └── api/
│   │       └── bookings/
│   │           └── route.ts        # POST /api/bookings
│   │
│   ├── components/
│   │   ├── canvas/
│   │   │   └── ScrollSequence.tsx  # ⭐ Core cinematic component
│   │   ├── forms/
│   │   │   └── BookingForm.tsx     # Private viewing request form
│   │   ├── layout/
│   │   │   └── Navigation.tsx      # Cinematic nav with section dots
│   │   └── ui/
│   │       ├── LoadingScreen.tsx   # Cinematic loading experience
│   │       └── BookingModal.tsx    # Full-screen booking overlay
│   │
│   ├── hooks/                      # Custom React hooks
│   │
│   ├── lib/
│   │   ├── animation/
│   │   │   ├── scroll-to-frame.ts  # Frame math, easing, mapping
│   │   │   ├── frame-preloader.ts  # Asset loading system
│   │   │   ├── lenis-provider.tsx  # Smooth scroll context
│   │   │   └── section-configs.ts  # 5-section frame configurations
│   │   └── supabase/
│   │       ├── client.ts           # Supabase client (browser + server)
│   │       └── schema.sql          # Database schema
│   │
│   ├── types/
│   │   └── index.ts                # All TypeScript interfaces
│   │
│   └── styles/
│       └── globals.css             # Global styles + CSS tokens
│
├── public/
│   └── frames/
│       ├── section1/               # 100 WebP frames (interior → window)
│       ├── section2/               # 90 WebP frames (skyline reveal)
│       ├── section3/               # 120 WebP frames (tower rotation)
│       ├── section4/               # 100 WebP frames (wireframe morph)
│       └── section5/               # 120 WebP frames (particle earth)
│
├── scripts/
│   ├── optimize-frames.js          # PNG→WebP batch converter
│   └── generate-placeholders.js   # Dev placeholder generator
│
├── next.config.js
├── tailwind.config.ts
├── tsconfig.json
├── vercel.json
└── .env.example
```

---

## Cinematic System

### How it works

```
Scroll Position
     │
     ▼
useScroll() [Framer Motion]
     │
     ▼
scrollYProgress (0 → 1) within section container
     │
     ▼
scrollProgressToFrame() [easeInOutSine]
     │
     ▼
frameIndex (0 → N-1)
     │
     ▼
requestAnimationFrame()
     │
     ▼
canvas.drawImage(frames[frameIndex], ...)
```

### Frame naming convention

```
/public/frames/section1/frame_0000.webp
/public/frames/section1/frame_0001.webp
...
/public/frames/section1/frame_0099.webp
```

### Rendering strategy

Each section uses a sticky container:
- `height: 400vh` (scroll distance)
- `sticky top-0 height-screen` (viewport-pinned canvas)
- `canvas` fills viewport, renders at `devicePixelRatio × 2` (capped)

---

## Phase 1: Setup

```bash
# Clone / initialize
git clone https://github.com/your-org/lodha-cinematic
cd lodha-cinematic

# Install dependencies
npm install

# Copy environment template
cp .env.example .env.local
# → Fill in Supabase + Make.com values

# Generate placeholder frames (dev only)
node scripts/generate-placeholders.js

# Start dev server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Phase 2: 3D Assets

### Render specifications

| Section | Software | Frames | Resolution | Format |
|---------|----------|--------|------------|--------|
| 1 – Arrival | Blender 4.0 | 100 | 1920×1080 | PNG → WebP |
| 2 – Skyline | Blender 4.0 | 90 | 1920×1080 | PNG → WebP |
| 3 – Tower | Blender 4.0 | 120 | 1920×1080 | PNG → WebP |
| 4 – Blueprint | Blender 4.0 | 100 | 1920×1080 | PNG → WebP |
| 5 – Earth | Blender 4.0 | 120 | 1920×1080 | PNG → WebP |

### Blender render setup

```python
# Blender Python — batch render frames
import bpy

bpy.context.scene.render.resolution_x = 1920
bpy.context.scene.render.resolution_y = 1080
bpy.context.scene.render.fps = 24
bpy.context.scene.frame_start = 0
bpy.context.scene.frame_end = 99  # Adjust per section
bpy.context.scene.render.image_settings.file_format = 'PNG'
bpy.context.scene.render.filepath = '//raw-frames/section1/frame_'
bpy.ops.render.render(animation=True)
```

### Convert to WebP

```bash
# Place rendered PNGs in raw-frames/section1/
node scripts/optimize-frames.js --section=1 --quality=80

# All sections
node scripts/optimize-frames.js
```

---

## Phase 3: Supabase

### Setup

1. Create project at [supabase.com](https://supabase.com)
2. Copy `Project URL` and `anon` key → `.env.local`
3. Run schema in SQL Editor:

```sql
-- Copy/paste contents of: src/lib/supabase/schema.sql
```

### Make.com Webhook

1. Create account at [make.com](https://make.com)
2. New Scenario → Add Module → Webhooks → Custom Webhook
3. Copy webhook URL → `MAKE_WEBHOOK_URL` in `.env.local`
4. Add modules: Gmail (confirmation email) + Slack (team alert)

---

## Phase 4: Deployment

### GitHub → Vercel

```bash
# Push to GitHub
git add .
git commit -m "feat: initial cinematic experience"
git push origin main
```

1. Open [vercel.com/new](https://vercel.com/new)
2. Import your GitHub repository
3. Add environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `MAKE_WEBHOOK_URL`
   - `WEBHOOK_SECRET`
4. Deploy → `https://lodha-cinematic.vercel.app`

### Vercel CLI

```bash
npm i -g vercel
vercel login
vercel --prod
```

---

## Performance Checklist

### Target Metrics (Lighthouse)
- Performance: ≥ 90
- LCP: < 2.5s
- FID: < 100ms
- CLS: < 0.1

### Frame Asset Budget

| Section | Frames | ~Size/frame | Total |
|---------|--------|-------------|-------|
| 1 | 100 | 80KB | 8MB |
| 2 | 90 | 80KB | 7.2MB |
| 3 | 120 | 85KB | 10.2MB |
| 4 | 100 | 75KB | 7.5MB |
| 5 | 120 | 90KB | 10.8MB |
| **Total** | **530** | — | **~44MB** |

### Loading strategy
- ✅ Section 1 (first 20 frames) loaded before any interaction
- ✅ Sections 2–5 lazy-loaded as user scrolls
- ✅ WebP format (avg 70% smaller than PNG)
- ✅ Canvas 2× DPR cap (prevents memory issues on Retina)
- ✅ `next/image` + immutable cache headers on `/frames/*`
- ✅ Preload `frame_0000.webp` and `frame_0001.webp` in `<head>`

### Code splitting
- ✅ `dynamic()` import per section component
- ✅ Framer Motion tree-shaking
- ✅ No heavy 3D libraries (Three.js, Babylon) — pure Canvas API

---

## Future Roadmap

### Phase 2 Enhancements
- [ ] WebGL shader transitions between sections
- [ ] Spatial audio design (ambient sound per section)
- [ ] Mobile haptic feedback on section transitions
- [ ] 360° virtual property tour integration

### Phase 3 Features
- [ ] CRM dashboard for leads (React admin panel)
- [ ] WhatsApp Business API integration
- [ ] Multi-property landing pages
- [ ] A/B testing (Vercel Edge Config)

### Performance
- [ ] Service Worker for offline frame caching
- [ ] Adaptive quality based on connection speed
- [ ] AVIF format for supported browsers
- [ ] VideoFrame API for hardware-decoded sequences

---

## License

Proprietary — Lodha Group / Macrotech Developers Ltd.  
All rights reserved.
